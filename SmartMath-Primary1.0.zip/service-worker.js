// Service Worker for 小学数学练习小程序
// 功能：PWA离线支持、缓存管理、更新通知
// 版本：v2（支持自动清理旧缓存）

// 缓存名称（使用版本号，便于更新时清理旧缓存）
const CACHE_NAME = 'math-practice-v2';

// 需要缓存的资源列表
// 包括：HTML页面、JavaScript文件、外部CDN资源
const urlsToCache = [
    './',                              // 根目录
    './index.html',                      // 首页
    './practice.html',                   // 练习页
    './progress.html',                    // 进度页
    './main.js',                        // 主逻辑脚本
    './math-generator.js',               // 题目生成器
    './geometry-visualizer.js',           // 几何可视化
    './manifest.json',                   // PWA配置文件
    // 外部CDN资源（样式和动画库）
    'https://cdn.tailwindcss.com',
    'https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js',
    'https://fonts.googleapis.com/css2?family=Noto+Sans+SC:wght@400;500;700&display=swap'
];

// Service Worker安装事件
// 触发时机：首次访问或检测到新版本时
self.addEventListener('install', event => {
  // 等待缓存操作完成
  event.waitUntil(
    // 打开缓存
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Opened cache');
        // 将所有资源添加到缓存
        return cache.addAll(urlsToCache);
      })
  );
});

// Service Worker网络请求事件
// 触发时机：每次页面发起网络请求时
self.addEventListener('fetch', event => {
  // 尝试从缓存中查找请求的资源
  event.respondWith(
    caches.match(event.request)
      .then(response => {
        // 如果缓存中有，直接返回缓存
        if (response) {
          return response;
        }
        // 如果缓存中没有，发起网络请求
        return fetch(event.request).then(
          response => {
            // 检查响应是否有效
            if(!response || response.status !== 200 || response.type !== 'basic') {
              // 无效响应直接返回
              return response;
            }
            // 克隆响应对象（因为响应流只能使用一次）
            const responseToCache = response.clone();
            // 打开缓存并存储响应
            caches.open(CACHE_NAME)
              .then(cache => {
                cache.put(event.request, responseToCache);
              });
            // 返回网络响应
            return response;
          }
        );
      })
  );
});

self.addEventListener('activate', event => {
  const cacheWhitelist = [CACHE_NAME];
  event.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cacheName => {
          if (cacheWhitelist.indexOf(cacheName) === -1) {
            console.log('Deleting old cache:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
  
  // 立即控制所有客户端
  event.waitUntil(
    self.clients.claim()
  );
  
  // 通知所有客户端有新版本可用
  self.clients.matchAll().then(clients => {
    clients.forEach(client => {
      client.postMessage({ type: 'UPDATE_AVAILABLE' });
    });
  });
});