console.log("生成器脚本已成功启动！(版本: 2026-02-27 修复版)");

// 数学题目生成器 - 确保题目不重复且没有互换形式，支持多种答案格式

class MathGenerator {
    // 静态缓存，避免重复读取localStorage
    static questionHistoryCache = null;
    static MAX_HISTORY_SIZE = 50;
    static HISTORY_DAYS = 3;

    constructor() {
        if (!MathGenerator.questionHistoryCache) {
            MathGenerator.questionHistoryCache = this.loadHistory();
        }
    }

    // 难度管理
    static difficultySettings = {
        addition: {
            min: 1,
            max: 20,
            step: 10
        },
        subtraction: {
            min: 1,
            max: 20,
            step: 10
        },
        multiplication: {
            min: 1,
            max: 9,
            step: 3
        },
        division: {
            min: 1,
            max: 9,
            step: 3
        }
    };

    // 连续答对计数器
    static correctStreak = 0;

    // 重置难度
    static resetDifficulty() {
        this.difficultySettings = {
            addition: { min: 1, max: 20, step: 10 },
            subtraction: { min: 1, max: 20, step: 10 },
            multiplication: { min: 1, max: 9, step: 3 },
            division: { min: 1, max: 9, step: 3 }
        };
        this.correctStreak = 0;
    }

    // 更新连续答对计数
    static updateCorrectStreak(isCorrect) {
        if (isCorrect) {
            this.correctStreak++;
            // 每连续答对3题，增加难度
            if (this.correctStreak % 3 === 0) {
                this.increaseDifficulty();
            }
        } else {
            this.correctStreak = 0;
            // 答错时适当降低难度
            this.decreaseDifficulty();
        }
    }

    // 增加难度
    static increaseDifficulty() {
        for (const [operation, settings] of Object.entries(this.difficultySettings)) {
            if (operation === 'addition' || operation === 'subtraction') {
                settings.max = Math.min(settings.max + settings.step, 100);
            } else if (operation === 'multiplication' || operation === 'division') {
                settings.max = Math.min(settings.max + settings.step, 19);
            }
        }
    }

    // 降低难度
    static decreaseDifficulty() {
        for (const [operation, settings] of Object.entries(this.difficultySettings)) {
            if (operation === 'addition' || operation === 'subtraction') {
                settings.max = Math.max(settings.max - settings.step / 2, 20);
            } else if (operation === 'multiplication' || operation === 'division') {
                settings.max = Math.max(settings.max - settings.step / 2, 9);
            }
        }
    }

    // 最大公约数 - 用于分数化简
    static gcd(a, b) {
        a = Math.abs(a);
        b = Math.abs(b);
        while (b) {
            const t = b;
            b = a % b;
            a = t;
        }
        return a;
    }

    // 化简分数
    static simplifyFraction(numerator, denominator) {
        if (denominator === 0) return { numerator: 0, denominator: 1 };
        const divisor = this.gcd(numerator, denominator);
        return {
            numerator: numerator / divisor,
            denominator: denominator / divisor
        };
    }

    // 小数精度处理 - 倍率法
    static preciseDecimalOperation(a, b, operation) {
        // 确定小数点后的位数
        const decimalPlaces = Math.max(
            (a.toString().split('.')[1] || '').length,
            (b.toString().split('.')[1] || '').length
        );
        
        // 计算倍率
        const multiplier = Math.pow(10, decimalPlaces);
        
        // 将小数转换为整数
        const intA = Math.round(a * multiplier);
        const intB = Math.round(b * multiplier);
        
        // 执行整数运算
        let result;
        switch (operation) {
            case '+':
                result = intA + intB;
                break;
            case '-':
                result = intA - intB;
                break;
            case '×':
            case '*':
                result = intA * intB;
                // 对于乘法，需要调整倍率
                return result / (multiplier * multiplier);
            case '÷':
            case '/':
                if (intB === 0) return 0;
                return (intA / intB) / 1;
            default:
                return 0;
        }
        
        // 还原为小数
        return result / multiplier;
    }

    // 加载历史记录（带时间戳）
    loadHistory() {
        const saved = localStorage.getItem('mathQuestionHistory');
        if (saved) {
            try {
                const data = JSON.parse(saved);
                // 过滤掉超过3天的记录
                const threeDaysAgo = Date.now() - (MathGenerator.HISTORY_DAYS * 24 * 60 * 60 * 1000);
                const filtered = data.filter(item => {
                    if (typeof item === 'object' && item.timestamp) {
                        return item.timestamp > threeDaysAgo;
                    }
                    return true;
                });
                return new Set(filtered.map(item => 
                    typeof item === 'object' ? item.question : item
                ));
            } catch (e) {
                return new Set();
            }
        }
        return new Set();
    }

    // 保存历史记录（带时间戳）
    saveHistory() {
        const now = Date.now();
        const data = [...MathGenerator.questionHistoryCache].map(question => ({
            question,
            timestamp: now
        }));
        // 限制历史记录数量
        if (data.length > MathGenerator.MAX_HISTORY_SIZE) {
            data.splice(0, data.length - MathGenerator.MAX_HISTORY_SIZE);
        }
        localStorage.setItem('mathQuestionHistory', JSON.stringify(data));
    }

    // 生成题目（支持错题优先）
    static generateQuestion(grade, prioritizeMistakes = true) {
        // 函数映射表 - 使用映射表替代switch-case
        const gradeMap = {
            1: () => this.generateGrade1Question(),
            2: () => this.generateGrade2Question(),
            3: () => this.generateGrade3Question(),
            4: () => this.generateGrade4Question(),
            5: () => this.generateGrade5Question(),
            6: () => this.generateGrade6Question()
        };
        
        // 30%概率从错题本中抽题
        if (prioritizeMistakes && Math.random() < 0.3) {
            const mistakeQuestion = this.getMistakeQuestion(grade);
            if (mistakeQuestion) {
                return mistakeQuestion;
            }
        }

        let question;
        let attempts = 0;
        
        do {
            try {
                const generatorFunc = gradeMap[grade] || gradeMap[1];
                question = generatorFunc();
            } catch (error) {
                console.error('生成题目时出错:', error);
                question = null;
            }
            
            attempts++;
        } while ((!question || this.isDuplicateQuestion(question.question)) && attempts < 50);
        
        if (!question) {
            console.warn('50次尝试后仍无法生成新题目，使用备用题目');
            question = {
                question: `${Math.floor(Math.random() * 10) + 1} + ${Math.floor(Math.random() * 10) + 1} = ?`,
                answer: '0',
                type: '基础练习',
                grade: grade,
                hint: '请继续练习',
                solution: [{ desc: "系统提示", detail: "已为您刷新一组新题" }]
            };
        }
        
        this.addToHistory(question.question);
        
        return question;
    }

    // 从错题本中获取题目
    static getMistakeQuestion(grade) {
        try {
            const mistakes = JSON.parse(localStorage.getItem('mistake_list') || '[]');
            const gradeMistakes = mistakes.filter(m => m.grade === grade);
            
            if (gradeMistakes.length > 0) {
                const randomMistake = gradeMistakes[Math.floor(Math.random() * gradeMistakes.length)];
                return {
                    question: randomMistake.question,
                    answer: randomMistake.correctAnswer || randomMistake.answer,
                    answerType: randomMistake.answerType || 'number',
                    type: randomMistake.type || '错题重练',
                    grade: randomMistake.grade,
                    isMistakeReview: true
                };
            }
        } catch (e) {
            console.log('获取错题失败:', e);
        }
        return null;
    }

    // 检查题目是否重复（包括等价形式）
    static isDuplicateQuestion(questionStr) {
        new MathGenerator();
        
        if (MathGenerator.questionHistoryCache.has(questionStr)) {
            return true;
        }

        const equivalentForms = this.getEquivalentForms(questionStr);
        for (let form of equivalentForms) {
            if (MathGenerator.questionHistoryCache.has(form)) {
                return true;
            }
        }

        return false;
    }

    // 获取等价形式
    static getEquivalentForms(questionStr) {
        const forms = [];
        
        // 处理分数等价形式
        const fractionMatch = questionStr.match(/(\d+)\/(\d+)/);
        if (fractionMatch) {
            const num = parseInt(fractionMatch[1]);
            const den = parseInt(fractionMatch[2]);
            const gcd = this.gcd(num, den);
            const simplified = `${num/gcd}/${den/gcd}`;
            forms.push(questionStr.replace(/(\d+)\/(\d+)/, simplified));
        }
        
        // 处理乘法交换律 (a×b = b×a)
        const mulMatch = questionStr.match(/^(\d+)\s*×\s*(\d+)\s*=/);
        if (mulMatch) {
            const a = parseInt(mulMatch[1]);
            const b = parseInt(mulMatch[2]);
            forms.push(`${b} × ${a} =`);
        }

        // 处理加法交换律 (a+b = b+a)
        const addMatch = questionStr.match(/^(\d+)\s*\+\s*(\d+)\s*=/);
        if (addMatch) {
            const a = parseInt(addMatch[1]);
            const b = parseInt(addMatch[2]);
            forms.push(`${b} + ${a} =`);
        }

        // 处理减法避免重复 (16-7 和 16-7)
        const subMatch = questionStr.match(/^(\d+)\s*-\s*(\d+)\s*=/);
        if (subMatch) {
            const a = parseInt(subMatch[1]);
            const b = parseInt(subMatch[2]);
            // 减法没有交换律，但避免相同的题目
            forms.push(`${a} - ${b} =`);
        }

        return forms;
    }

    // 添加到历史记录
    static addToHistory(questionStr) {
        new MathGenerator();
        MathGenerator.questionHistoryCache.add(questionStr);
        const instance = new MathGenerator();
        instance.saveHistory();
    }

    // 清空历史记录
    static clearHistory() {
        MathGenerator.questionHistoryCache = new Set();
        localStorage.removeItem('mathQuestionHistory');
    }

    // 一年级题目：加减法
    static generateGrade1Question() {
        const types = ['addition', 'subtraction', 'application'];
        const type = types[Math.floor(Math.random() * types.length)];
        
        if (type === 'application') {
            return this.generateApplicationQuestion(1);
        }
        
        const operations = ['+', '-'];
        const operation = operations[Math.floor(Math.random() * operations.length)];
        let a, b, answer;
        const max = operation === '+' ? this.difficultySettings.addition.max : this.difficultySettings.subtraction.max;

        if (operation === '+') {
            a = Math.floor(Math.random() * max) + 1;
            b = Math.floor(Math.random() * (max - a + 1)) + 1;
            answer = a + b;
        } else {
            a = Math.floor(Math.random() * max) + 1;
            b = Math.floor(Math.random() * a) + 1;
            answer = a - b;
        }

        const hint = operation === '+' 
            ? `试着从 ${a} 开始，往后数 ${b} 个数。`
            : `从 ${a} 开始，往前数 ${b} 个数。`;

        const solution = operation === '+'
            ? [
                { desc: "认清数字", detail: `这道题是把 ${a} 和 ${b} 合起来。` },
                { desc: "计算过程", detail: `${a} 加上 ${b} 等于 ${answer}。` }
            ]
            : [
                { desc: "认清数字", detail: `这道题是从 ${a} 中减去 ${b}。` },
                { desc: "计算过程", detail: `${a} 减去 ${b} 等于 ${answer}。` }
            ];

        return {
            question: `${a} ${operation} ${b} =`,
            answer: answer,
            answerType: 'number',
            type: `${max}以内` + (operation === '+' ? '加法' : '减法'),
            grade: 1,
            hint: hint,
            solution: solution
        };
    }

    // 二年级题目：乘除法
    static generateGrade2Question() {
        const types = ['multiplication', 'division', 'application'];
        const type = types[Math.floor(Math.random() * types.length)];
        
        if (type === 'application') {
            return this.generateApplicationQuestion(2);
        }
        
        const operations = ['×', '÷'];
        const operation = operations[Math.floor(Math.random() * operations.length)];
        let a, b, answer;
        const max = operation === '×' ? this.difficultySettings.multiplication.max : this.difficultySettings.division.max;

        if (operation === '×') {
            a = Math.floor(Math.random() * max) + 1;
            b = Math.floor(Math.random() * max) + 1;
            answer = a * b;
            return {
                question: `${a} × ${b} =`,
                answer: answer,
                answerType: 'number',
                type: `${max}以内乘法`,
                grade: 2,
                hint: `可以把 ${b} 看作 ${b} 个 ${a} 相加。`,
                solution: [
                    { desc: "认清数字", detail: `这道题是计算 ${a} 乘以 ${b}。` },
                    { desc: "计算过程", detail: `${a} × ${b} = ${a} + ${a} + ...（共${b}个${a}）= ${answer}` },
                    { desc: "结果", detail: `答案是 ${answer}` }
                ]
            };
        } else {
            b = Math.floor(Math.random() * max) + 1;
            answer = Math.floor(Math.random() * max) + 1;
            a = b * answer;
            return {
                question: `${a} ÷ ${b} =`,
                answer: answer,
                answerType: 'number',
                type: `${max}以内除法`,
                grade: 2,
                hint: `想一想：${b} 乘以多少等于 ${a}？`,
                solution: [
                    { desc: "认清数字", detail: `这道题是计算 ${a} 除以 ${b}。` },
                    { desc: "计算过程", detail: `${a} ÷ ${b} = ${answer}，因为 ${b} × ${answer} = ${a}` },
                    { desc: "结果", detail: `答案是 ${answer}` }
                ]
            };
        }
    }

    // 三年级题目：多位数运算
    static generateGrade3Question() {
        const types = ['multiplication', 'division', 'addition', 'subtraction', 'decimal', 'application'];
        const type = types[Math.floor(Math.random() * types.length)];
        
        if (type === 'application') {
            return this.generateApplicationQuestion(3);
        }
        
        let a, b, answer;

        switch (type) {
            case 'multiplication': {
                a = Math.floor(Math.random() * 90) + 10; // 两位数
                b = Math.floor(Math.random() * 9) + 1;   // 一位数
                answer = a * b;
                return {
                    question: `${a} × ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: '两位数乘一位数',
                    grade: 3
                };
            }
            case 'division': {
                b = Math.floor(Math.random() * 9) + 1;   // 一位数除数
                answer = Math.floor(Math.random() * 100) + 10;
                a = b * answer;
                return {
                    question: `${a} ÷ ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: '除数是一位数的除法',
                    grade: 3
                };
            }
            case 'decimal': {
                a = (Math.random() * 10).toFixed(1);
                b = (Math.random() * 10).toFixed(1);
                answer = this.preciseDecimalOperation(parseFloat(a), parseFloat(b), '+');
                answer = parseFloat(answer.toFixed(1));
                return {
                    question: `${a} + ${b} =`,
                    answer: answer,
                    answerType: 'decimal',
                    type: '小数加法',
                    grade: 3
                };
            }
            case 'addition': {
                a = Math.floor(Math.random() * 900) + 100; // 三位数
                b = Math.floor(Math.random() * 900) + 100;
                answer = a + b;
                return {
                    question: `${a} + ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: '三位数加法',
                    grade: 3
                };
            }
            default: { // subtraction
                a = Math.floor(Math.random() * 900) + 500; // 确保结果为正
                b = Math.floor(Math.random() * a) + 100;
                answer = a - b;
                return {
                    question: `${a} - ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: '三位数减法',
                    grade: 3
                };
            }
        }
    }

    // 四年级题目：四则混合运算
    static generateGrade4Question() {
        if (Math.random() < 0.3) {
            return this.generateApplicationQuestion(4);
        }
        
        const patterns = [
            () => {
                const a = Math.floor(Math.random() * 50) + 10;
                const b = Math.floor(Math.random() * 50) + 10;
                const c = Math.floor(Math.random() * 50) + 10;
                return {
                    question: `${a} + ${b} - ${c} =`,
                    answer: a + b - c,
                    answerType: 'number',
                    type: '加减混合运算'
                };
            },
            () => {
                const a = Math.floor(Math.random() * 20) + 5;
                const b = Math.floor(Math.random() * 20) + 5;
                const c = Math.floor(Math.random() * 10) + 1;
                return {
                    question: `${a} × ${b} + ${c} =`,
                    answer: a * b + c,
                    answerType: 'number',
                    type: '乘加混合运算'
                };
            },
            () => {
                const a = Math.floor(Math.random() * 20) + 10;
                const b = Math.floor(Math.random() * 9) + 1;
                const c = Math.floor(Math.random() * 9) + 1;
                return {
                    question: `${a} + ${b} × ${c} =`,
                    answer: a + b * c,
                    answerType: 'number',
                    type: '加乘混合运算'
                };
            },
            () => {
                // 小数减法
                const a = (Math.random() * 10 + 5).toFixed(1);
                const b = (Math.random() * 5).toFixed(1);
                const answer = MathGenerator.preciseDecimalOperation(parseFloat(a), parseFloat(b), '-');
                return {
                    question: `${a} - ${b} =`,
                    answer: parseFloat(answer.toFixed(1)),
                    answerType: 'decimal',
                    type: '小数减法'
                };
            }
        ];

        const pattern = patterns[Math.floor(Math.random() * patterns.length)];
        return {
            ...pattern(),
            grade: 4
        };
    }

    // 五年级题目：小数分数运算
    static generateGrade5Question() {
        const types = ['decimal_add', 'decimal_sub', 'decimal_mul', 'fraction_add', 'fraction_sub', 'percent', 'geometry_rect', 'geometry_square', 'geometry_triangle', 'equation', 'tf', 'choice', 'application'];
        const type = types[Math.floor(Math.random() * types.length)];

        switch (type) {
            case 'decimal_add': {
                const a1 = (Math.random() * 10).toFixed(1);
                const b1 = (Math.random() * 10).toFixed(1);
                const answer1 = this.preciseDecimalOperation(parseFloat(a1), parseFloat(b1), '+');
                return {
                    question: `${a1} + ${b1} =`,
                    answer: parseFloat(answer1.toFixed(1)),
                    answerType: 'decimal',
                    type: '小数加法',
                    hint: '小数加法要对齐小数点，从低位加起',
                    solution: [
                        { desc: "对齐小数点", detail: `将 ${a1} 和 ${b1} 的小数点对齐` },
                        { desc: "计算过程", detail: `${a1} + ${b1} = ${parseFloat(answer1.toFixed(1))}` },
                        { desc: "结果", detail: `答案是 ${parseFloat(answer1.toFixed(1))}` }
                    ]
                };
            }
            case 'decimal_sub': {
                const a2 = (Math.random() * 10 + 5).toFixed(1);
                const b2 = (Math.random() * 5).toFixed(1);
                const answer2 = this.preciseDecimalOperation(parseFloat(a2), parseFloat(b2), '-');
                return {
                    question: `${a2} - ${b2} =`,
                    answer: parseFloat(answer2.toFixed(1)),
                    answerType: 'decimal',
                    type: '小数减法',
                    hint: '小数减法要对齐小数点，从低位减起，不够减要借位',
                    solution: [
                        { desc: "对齐小数点", detail: `将 ${a2} 和 ${b2} 的小数点对齐` },
                        { desc: "计算过程", detail: `${a2} - ${b2} = ${parseFloat(answer2.toFixed(1))}` },
                        { desc: "结果", detail: `答案是 ${parseFloat(answer2.toFixed(1))}` }
                    ]
                };
            }
            case 'decimal_mul': {
                const a3 = (Math.random() * 5 + 1).toFixed(1);
                const b3 = Math.floor(Math.random() * 10) + 1;
                const answer3 = this.preciseDecimalOperation(parseFloat(a3), b3, '×');
                return {
                    question: `${a3} × ${b3} =`,
                    answer: parseFloat(answer3.toFixed(1)),
                    answerType: 'decimal',
                    type: '小数乘法',
                    hint: '小数乘法先按整数乘，再看因数中一共有几位小数，就从积的右边起数出几位点上小数点',
                    solution: [
                        { desc: "按整数计算", detail: `先计算 ${a3} × ${b3}（忽略小数点）` },
                        { desc: "确定小数位数", detail: `${a3} 有1位小数，${b3} 是整数，共1位小数` },
                        { desc: "点小数点", detail: `从积的右边起数出1位点上小数点，答案是 ${parseFloat(answer3.toFixed(1))}` }
                    ]
                };
            }
            case 'fraction_add': {
                const den = Math.floor(Math.random() * 8) + 2;
                const num1 = Math.floor(Math.random() * den) + 1;
                const num2 = Math.floor(Math.random() * (den - num1)) + 1;
                const sumNum = num1 + num2;
                const simplified1 = this.simplifyFraction(sumNum, den);
                return {
                    question: `${num1}/${den} + ${num2}/${den} =`,
                    answer: simplified1.numerator + '/' + simplified1.denominator,
                    answerType: 'fraction',
                    type: '同分母分数加法',
                    hint: '同分母分数相加，分母不变，分子相加',
                    solution: [
                        { desc: "认清分数", detail: `两个分数的分母都是 ${den}` },
                        { desc: "计算过程", detail: `分子相加：${num1} + ${num2} = ${sumNum}，分母保持 ${den}` },
                        { desc: "化简结果", detail: simplified1.numerator === sumNum ? `答案已经是 ${sumNum}/${den}` : `化简：${sumNum}/${den} = ${simplified1.numerator}/${simplified1.denominator}` }
                    ]
                };
            }
            case 'fraction_sub': {
                const den2 = Math.floor(Math.random() * 8) + 2;
                const num3 = Math.floor(Math.random() * den2) + 3;
                const num4 = Math.floor(Math.random() * (num3 - 1)) + 1;
                const diffNum = num3 - num4;
                const simplified2 = this.simplifyFraction(diffNum, den2);
                return {
                    question: `${num3}/${den2} - ${num4}/${den2} =`,
                    answer: simplified2.numerator + '/' + simplified2.denominator,
                    answerType: 'fraction',
                    type: '同分母分数减法',
                    hint: '同分母分数相减，分母不变，分子相减',
                    solution: [
                        { desc: "认清分数", detail: `两个分数的分母都是 ${den2}` },
                        { desc: "计算过程", detail: `分子相减：${num3} - ${num4} = ${diffNum}，分母保持 ${den2}` },
                        { desc: "化简结果", detail: simplified2.numerator === diffNum ? `答案已经是 ${diffNum}/${den2}` : `化简：${diffNum}/${den2} = ${simplified2.numerator}/${simplified2.denominator}` }
                    ]
                };
            }
            case 'percent': {
                const num = Math.floor(Math.random() * 100) + 1;
                const percent = Math.floor(Math.random() * 50) + 10;
                return {
                    question: `${num} 的 ${percent}% 是多少？`,
                    answer: num * percent / 100,
                    answerType: 'number',
                    type: '百分数计算'
                };
            }
            case 'geometry_rect': {
                const rectW = Math.floor(Math.random() * 15) + 5;
                const rectH = Math.floor(Math.random() * 10) + 3;
                const rectArea = rectW * rectH;
                const rectPerimeter = 2 * (rectW + rectH);
                const rectType = Math.random() > 0.5 ? 'area' : 'perimeter';
                if (rectType === 'area') {
                    return {
                        question: `已知长方形的长为 ${rectW}，宽为 ${rectH}，求面积 S =`,
                        answer: rectArea,
                        answerType: 'number',
                        type: '长方形面积',
                        grade: 5,
                        category: 'geometry',
                        shape: 'rectangle',
                        params: { width: rectW, height: rectH },
                        hint: '长方形的面积公式是：面积 = 长 × 宽',
                        solution: [
                            { desc: "确定公式", detail: '长方形面积 S = 长 × 宽' },
                            { desc: "代入数值", detail: `S = ${rectW} (长) × ${rectH} (宽)` },
                            { desc: "计算结果", detail: `S = ${rectArea}` }
                        ]
                    };
                } else {
                    return {
                        question: `已知长方形的长为 ${rectW}，宽为 ${rectH}，求周长 C =`,
                        answer: rectPerimeter,
                        answerType: 'number',
                        type: '长方形周长',
                        grade: 5,
                        category: 'geometry',
                        shape: 'rectangle',
                        params: { width: rectW, height: rectH },
                        hint: '长方形的周长公式是：周长 = (长 + 宽) × 2',
                        solution: [
                            { desc: "确定公式", detail: '长方形周长 C = (长 + 宽) × 2' },
                            { desc: "代入数值", detail: `C = (${rectW} + ${rectH}) × 2` },
                            { desc: "计算结果", detail: `C = ${rectW + rectH} ×2 = ${rectPerimeter}` }
                        ]
                    };
                }
            }
            case 'geometry_square': {
                const squareSide = Math.floor(Math.random() * 12) + 3;
                const squareArea = squareSide * squareSide;
                const squarePerimeter = 4 * squareSide;
                const squareType = Math.random() > 0.5 ? 'area' : 'perimeter';
                if (squareType === 'area') {
                    return {
                        question: `已知正方形的边长为 ${squareSide}，求面积 S =`,
                        answer: squareArea,
                        answerType: 'number',
                        type: '正方形面积',
                        grade: 5,
                        category: 'geometry',
                        shape: 'square',
                        params: { side: squareSide },
                        hint: '正方形的面积公式是：面积 = 边长 × 边长',
                        solution: [
                            { desc: "确定公式", detail: '正方形面积 S = 边长 × 边长' },
                            { desc: "代入数值", detail: `S = ${squareSide} × ${squareSide}` },
                            { desc: "计算结果", detail: `S = ${squareArea}` }
                        ]
                    };
                } else {
                    return {
                        question: `已知正方形的边长为 ${squareSide}，求周长 C =`,
                        answer: squarePerimeter,
                        answerType: 'number',
                        type: '正方形周长',
                        grade: 5,
                        category: 'geometry',
                        shape: 'square',
                        params: { side: squareSide },
                        hint: '正方形的周长公式是：周长 = 边长 × 4',
                        solution: [
                            { desc: "确定公式", detail: '正方形周长 C = 边长 × 4' },
                            { desc: "代入数值", detail: `C = ${squareSide} × 4` },
                            { desc: "计算结果", detail: `C = ${squarePerimeter}` }
                        ]
                    };
                }
            }
            case 'geometry_triangle': {
                const triBase = Math.floor(Math.random() * 12) + 4;
                const triHeight = Math.floor(Math.random() * 10) + 3;
                const triArea = (triBase * triHeight) / 2;
                return {
                    question: `已知三角形的底为 ${triBase}，高为 ${triHeight}，求面积 S =`,
                    answer: triArea,
                    answerType: 'number',
                    type: '三角形面积',
                    grade: 5,
                    category: 'geometry',
                    shape: 'triangle',
                    params: { base: triBase, height: triHeight },
                    hint: '三角形的面积公式是：面积 = 底 × 高 ÷ 2',
                    solution: [
                        { desc: "确定公式", detail: '三角形面积 S = 底 × 高 ÷ 2' },
                        { desc: "代入数值", detail: `S = ${triBase} (底) × ${triHeight} (高) ÷ 2` },
                        { desc: "计算结果", detail: `S = ${triBase * triHeight} ÷ 2 = ${triArea}` }
                    ]
                };
            }
            case 'tf': {
                return this.generateTFQuestion(5);
            }
            case 'choice': {
                return this.generateChoiceQuestion(5);
            }
            case 'equation': {
                return this.generateEquation(5);
            }
            case 'application': {
                return this.generateApplicationQuestion(5);
            }
            default: {
                return this.generateGrade1Question(); // 安全兜底，避免递归
            }
        }
    }

    // 判断题生成
    static generateTFQuestion(grade) {
        const scenarios = {
            1: [
                { q: "5 + 3 = 8", a: "正确", hint: "5加3确实等于8" },
                { q: "10 - 5 = 6", a: "错误", hint: "10减5应该等于5" },
                { q: "20以内最大的数是20", a: "正确", hint: "20以内包括20" }
            ],
            2: [
                { q: "3 × 4 = 12", a: "正确", hint: "3乘4等于12" },
                { q: "18 ÷ 3 = 5", a: "错误", hint: "18除以3等于6" },
                { q: "乘法口诀表中，9×9=81", a: "正确", hint: "9乘9确实等于81" }
            ],
            3: [
                { q: "三位数加三位数，和一定是四位数", a: "错误", hint: "例如100+100=200，还是三位数" },
                { q: "25 × 4 = 100", a: "正确", hint: "25乘4等于100" },
                { q: "0.5 + 0.5 = 1", a: "正确", hint: "0.5加0.5等于1" }
            ],
            4: [
                { q: "混合运算中，先算乘除后算加减", a: "正确", hint: "这是混合运算的规则" },
                { q: "12 + 8 × 2 = 40", a: "错误", hint: "应该先算8×2=16，再算12+16=28" },
                { q: "小数减法要对齐小数点", a: "正确", hint: "小数加减法都要对齐小数点" }
            ],
            5: [
                { q: "所有的长方形都是正方形", a: "错误", hint: "正方形是特殊的长方形，但长方形不一定是正方形" },
                { q: "圆的周长总是它直径的π倍", a: "正确", hint: "这是圆周率的定义" },
                { q: "三角形的内角和是180°", a: "正确", hint: "这是三角形的基本性质" },
                { q: "分数乘法是分子乘分子，分母乘分母", a: "正确", hint: "分数乘法的计算规则" }
            ],
            6: [
                { q: "圆的面积公式是S=πr²", a: "正确", hint: "圆的面积公式" },
                { q: "百分数就是分母为100的分数", a: "正确", hint: "百分数的定义" },
                { q: "比例的前项和后项同时乘一个数，比值不变", a: "错误", hint: "这个数不能是0" },
                { q: "圆锥的体积是等底等高圆柱体积的1/3", a: "正确", hint: "圆锥体积公式" }
            ]
        };
        
        const gradeScenarios = scenarios[grade] || scenarios[5];
        const item = gradeScenarios[Math.floor(Math.random() * gradeScenarios.length)];
        
        return {
            question: item.q,
            answer: item.a,
            displayType: 'tf',
            type: '概念判断题',
            grade: grade,
            hint: item.hint,
            solution: [
                { desc: "判断正误", detail: item.q },
                { desc: "正确答案", detail: item.a },
                { desc: "解析", detail: item.hint }
            ]
        };
    }

    // 选择题生成
    static generateChoiceQuestion(grade) {
        const questions = {
            1: [
                {
                    q: () => {
                        const a = Math.floor(Math.random() * 9) + 1;
                        const b = Math.floor(Math.random() * 9) + 1;
                        return { 
                            question: `${a} × ${b} = ?`, 
                            answer: (a * b).toString(), 
                            options: [(a * b - 2).toString(), (a * b).toString(), (a * b + 2).toString(), (a * b + 4).toString()], 
                            hint: `${a}乘${b}等于${a * b}` 
                        };
                    }
                },
                {
                    q: () => {
                        const b = Math.floor(Math.random() * 9) + 1;
                        const answer = Math.floor(Math.random() * 9) + 1;
                        const a = b * answer;
                        return { 
                            question: `${a} ÷ ${b} = ?`, 
                            answer: answer.toString(), 
                            options: [(answer - 1).toString(), answer.toString(), (answer + 1).toString(), (answer + 2).toString()], 
                            hint: `${a}除以${b}等于${answer}` 
                        };
                    }
                }
            ],
            2: [
                {
                    q: () => {
                        const a = Math.floor(Math.random() * 500) + 100;
                        const b = Math.floor(Math.random() * 500) + 100;
                        return { 
                            question: `${a} + ${b} = ?`, 
                            answer: (a + b).toString(), 
                            options: [(a + b - 10).toString(), (a + b).toString(), (a + b + 10).toString(), (a + b + 20).toString()], 
                            hint: `${a}加${b}等于${a + b}` 
                        };
                    }
                },
                {
                    q: () => {
                        const a = (Math.random() * 0.5 + 0.1).toFixed(1);
                        const b = (Math.random() * 0.5 + 0.1).toFixed(1);
                        const answer = (parseFloat(a) + parseFloat(b)).toFixed(1);
                        return { 
                            question: `${a} + ${b} = ?`, 
                            answer: answer, 
                            options: [(parseFloat(answer) - 0.1).toFixed(1), answer, (parseFloat(answer) + 0.1).toFixed(1), (parseFloat(answer) + 0.2).toFixed(1)], 
                            hint: `${a}加${b}等于${answer}` 
                        };
                    }
                }
            ],
            3: [
                {
                    q: () => {
                        const a = Math.floor(Math.random() * 20) + 10;
                        const b = Math.floor(Math.random() * 5) + 2;
                        const c = Math.floor(Math.random() * 10) + 5;
                        return { 
                            question: `${a} + ${b} × ${c} = ?`, 
                            answer: (a + b * c).toString(), 
                            options: [(a + b * c - 5).toString(), (a + b * c).toString(), (a + b * c + 5).toString(), (a + b * c + 10).toString()], 
                            hint: `先算${b}×${c}=${b*c}，再加${a}` 
                        };
                    }
                },
                {
                    q: () => {
                        const a = Math.floor(Math.random() * 20) + 10;
                        const b = Math.floor(Math.random() * 5) + 2;
                        const c = Math.floor(Math.random() * 10) + 5;
                        return { 
                            question: `${a} - ${b} ÷ ${c} = ?`, 
                            answer: (a - Math.floor(b / c)).toString(), 
                            options: [(a - Math.floor(b / c) - 1).toString(), (a - Math.floor(b / c)).toString(), (a - Math.floor(b / c) + 1).toString(), (a - Math.floor(b / c) + 2).toString()], 
                            hint: `先算${b}÷${c}=${Math.floor(b/c)}，再减` 
                        };
                    }
                }
            ],
            4: [
                {
                    q: () => {
                        const width = Math.floor(Math.random() * 10) + 5;
                        const height = Math.floor(Math.random() * 8) + 3;
                        return { 
                            question: `长方形的长是${width}，宽是${height}，面积是多少？`, 
                            answer: (width * height).toString(), 
                            options: [(width * height - 5).toString(), (width * height).toString(), (width * height + 5).toString(), (width * height + 10).toString()], 
                            hint: `面积=长×宽=${width}×${height}` 
                        };
                    }
                },
                {
                    q: () => {
                        const num = Math.floor(Math.random() * 8) + 2;
                        const den = Math.floor(Math.random() * 8) + 2;
                        const sumNum = num + Math.floor(Math.random() * (den - num - 1)) + 1;
                        return { 
                            question: `${num}/${den} + 1/${den} = ?`, 
                            answer: `${sumNum}/${den}`, 
                            options: [`${sumNum-1}/${den}`, `${sumNum}/${den}`, `${sumNum+1}/${den}`, `${sumNum+2}/${den}`], 
                            hint: `同分母分数相加，分子相加` 
                        };
                    }
                }
            ],
            5: [
                {
                    q: () => {
                        const radius = Math.floor(Math.random() * 5) + 2;
                        return { 
                            question: `圆的半径是${radius}，面积是多少？(π取3.14)`, 
                            answer: Math.round(3.14 * radius * radius).toString(), 
                            options: [Math.round(3.14 * radius * radius - 5).toString(), Math.round(3.14 * radius * radius).toString(), Math.round(3.14 * radius * radius + 5).toString(), Math.round(3.14 * radius * radius + 10).toString()], 
                            hint: `圆面积=πr²=3.14×${radius}²` 
                        };
                    }
                },
                {
                    q: () => {
                        const num = Math.floor(Math.random() * 50) + 1;
                        const percent = Math.floor(Math.random() * 50) + 10;
                        return { 
                            question: `${num}的${percent}%是多少？`, 
                            answer: (num * percent / 100).toString(), 
                            options: [(num * percent / 100 - 2).toFixed(0), (num * percent / 100).toFixed(0), (num * percent / 100 + 2).toFixed(0), (num * percent / 100 + 4).toFixed(0)], 
                            hint: `${num}×${percent}%=${num * percent / 100}` 
                        };
                    }
                }
            ]
        };
        
        const gradeQuestions = questions[grade] || questions[1];
        const questionFunc = gradeQuestions[Math.floor(Math.random() * gradeQuestions.length)];
        const generated = questionFunc.q();
        
        return {
            question: generated.question,
            options: generated.options,
            answer: generated.answer,
            displayType: 'choice',
            type: '选择题',
            grade: grade,
            hint: generated.hint,
            solution: [
                { desc: "题目", detail: generated.question },
                { desc: "正确答案", detail: generated.answer },
                { desc: "解析", detail: generated.hint }
            ]
        };
    }

    // 应用题模板库 - 1-5年级
    static generateApplicationQuestion(grade) {
        const templates = {
            1: [
                // 1. 排队问题
                () => {
                    const front = Math.floor(Math.random() * 5) + 1;
                    const back = Math.floor(Math.random() * 5) + 1;
                    const total = front + back + 1;
                    return {
                        question: `小明排队买冰淇淋，他前面有 ${front} 人，后面有 ${back} 人，请问这一队一共有多少人？`,
                        answer: total,
                        answerType: 'number',
                        type: '排队问题',
                        grade: 1,
                        hint: "总人数 = 前面的人数 + 后面的人数 + 小明自己。",
                        solution: [
                            { desc: "理解题意", detail: `小明前面有 ${front} 人，后面有 ${back} 人` },
                            { desc: "列式计算", detail: `${front} + ${back} + 1 = ${total}` },
                            { desc: "得出结论", detail: `这一队一共有 ${total} 人。` }
                        ]
                    };
                },
                // 2. 找零钱
                () => {
                    const price = Math.floor(Math.random() * 9) + 1;
                    const paid = 10;
                    const change = paid - price;
                    return {
                        question: `小红买了一个笔记本，价格是 ${price} 元，她给了收银员 10 元，应该找回多少钱？`,
                        answer: change,
                        answerType: 'number',
                        type: '购物问题',
                        grade: 1,
                        hint: "找回的钱 = 付的钱 - 商品价格。",
                        solution: [
                            { desc: "理解题意", detail: `商品价格 ${price} 元，付款 10 元` },
                            { desc: "列式计算", detail: `10 - ${price} = ${change}` },
                            { desc: "得出结论", detail: `应该找回 ${change} 元。` }
                        ]
                    };
                },
                // 3. 时间经过
                () => {
                    const start = Math.floor(Math.random() * 5) + 8;
                    const minutes = Math.floor(Math.random() * 3) * 10;
                    const end = start + (minutes >= 60 ? 1 : 0);
                    const endMinutes = minutes % 60;
                    return {
                        question: `小明早上 ${start}:00 开始做作业，做了 ${minutes} 分钟，请问他什么时候做完？`,
                        answer: `${end}:${endMinutes === 0 ? '00' : endMinutes}`,
                        answerType: 'time',
                        type: '时间问题',
                        grade: 1,
                        hint: "结束时间 = 开始时间 + 经过时间。",
                        solution: [
                            { desc: "理解题意", detail: `开始时间 ${start}:00，经过 ${minutes} 分钟` },
                            { desc: "计算过程", detail: `${start}:00 + ${minutes}分钟 = ${end}:${endMinutes === 0 ? '00' : endMinutes}` },
                            { desc: "得出结论", detail: `小明 ${end}:${endMinutes === 0 ? '00' : endMinutes} 做完作业。` }
                        ]
                    };
                }
            ],
            2: [
                // 1. 乘法应用
                () => {
                    const num = Math.floor(Math.random() * 9) + 1;
                    const times = Math.floor(Math.random() * 9) + 1;
                    const total = num * times;
                    return {
                        question: `一盒巧克力有 ${num} 块，小明买了 ${times} 盒，一共有多少块巧克力？`,
                        answer: total,
                        answerType: 'number',
                        type: '乘法应用',
                        grade: 2,
                        hint: "总块数 = 每盒的块数 × 盒数。",
                        solution: [
                            { desc: "理解题意", detail: `每盒 ${num} 块，买了 ${times} 盒` },
                            { desc: "列式计算", detail: `${num} × ${times} = ${total}` },
                            { desc: "得出结论", detail: `一共有 ${total} 块巧克力。` }
                        ]
                    };
                },
                // 2. 除法应用
                () => {
                    const total = Math.floor(Math.random() * 8) + 1;
                    const num = total;
                    const people = Math.floor(Math.random() * 4) + 2;
                    const each = Math.floor(total / people);
                    return {
                        question: `有 ${total} 个苹果，平均分给 ${people} 个小朋友，每个小朋友分几个？`,
                        answer: each,
                        answerType: 'number',
                        type: '除法应用',
                        grade: 2,
                        hint: "每人分到的个数 = 总个数 ÷ 人数。",
                        solution: [
                            { desc: "理解题意", detail: `总共有 ${total} 个苹果，分给 ${people} 个小朋友` },
                            { desc: "列式计算", detail: `${total} ÷ ${people} = ${each}` },
                            { desc: "得出结论", detail: `每个小朋友分 ${each} 个苹果。` }
                        ]
                    };
                },
                // 3. 年龄问题
                () => {
                    const child = Math.floor(Math.random() * 5) + 5;
                    const parent = child + 25;
                    return {
                        question: `小明今年 ${child} 岁，妈妈比他大 25 岁，妈妈今年多少岁？`,
                        answer: parent,
                        answerType: 'number',
                        type: '年龄问题',
                        grade: 2,
                        hint: "妈妈的年龄 = 小明的年龄 + 年龄差。",
                        solution: [
                            { desc: "理解题意", detail: `小明 ${child} 岁，妈妈比他大 25 岁` },
                            { desc: "列式计算", detail: `${child} + 25 = ${parent}` },
                            { desc: "得出结论", detail: `妈妈今年 ${parent} 岁。` }
                        ]
                    };
                }
            ],
            3: [
                // 1. 鸡兔同笼（简易版）
                () => {
                    const heads = Math.floor(Math.random() * 5) + 3;
                    const legs = heads * 2 + Math.floor(Math.random() * 3) * 2;
                    const rabbits = (legs - heads * 2) / 2;
                    const chickens = heads - rabbits;
                    return {
                        question: `笼子里有若干只鸡和兔，从上面数有 ${heads} 个头，从下面数有 ${legs} 条腿，请问兔子有几只？`,
                        answer: rabbits,
                        answerType: 'number',
                        type: '鸡兔同笼',
                        grade: 3,
                        hint: "假设全是鸡，腿数会比实际少，少的腿数就是兔子的数量×2。",
                        solution: [
                            { desc: "假设全是鸡", detail: `如果全是鸡，应有 ${heads * 2} 条腿` },
                            { desc: "计算兔子数量", detail: `实际多了 ${legs - heads * 2} 条腿，每只兔子比鸡多2条腿，所以兔子有 ${(legs - heads * 2) / 2} 只` },
                            { desc: "得出结论", detail: `兔子有 ${rabbits} 只。` }
                        ]
                    };
                },
                // 2. 和差问题
                () => {
                    const sum = Math.floor(Math.random() * 50) + 20;
                    const diff = Math.floor(Math.random() * 10) + 1;
                    const larger = Math.floor((sum + diff) / 2);
                    return {
                        question: `甲乙两数的和是 ${sum}，差是 ${diff}，请问较大的数是多少？`,
                        answer: larger,
                        answerType: 'number',
                        type: '和差问题',
                        grade: 3,
                        hint: "较大的数 = (和 + 差) ÷ 2。",
                        solution: [
                            { desc: "公式应用", detail: `较大的数 = (和 + 差) ÷ 2` },
                            { desc: "代入计算", detail: `(${sum} + ${diff}) ÷ 2 = ${larger}` },
                            { desc: "得出结论", detail: `较大的数是 ${larger}。` }
                        ]
                    };
                },
                // 3. 周期问题
                () => {
                    const total = Math.floor(Math.random() * 20) + 10;
                    const cycle = 4;
                    const position = total % cycle === 0 ? cycle : total % cycle;
                    const days = ['星期一', '星期二', '星期三', '星期四', '星期五', '星期六', '星期日'];
                    const start = 0; // 星期一
                    const result = days[(start + total - 1) % 7];
                    return {
                        question: `今天是星期一，再过 ${total} 天是星期几？`,
                        answer: result,
                        answerType: 'string',
                        type: '周期问题',
                        grade: 3,
                        hint: "一周有7天，用总天数除以7，余数就是星期几的位置。",
                        solution: [
                            { desc: "计算周期", detail: `一周有7天，${total} ÷ 7 = ${Math.floor(total/7)} 周余 ${total%7} 天` },
                            { desc: "推算星期", detail: `从星期一开始，过 ${total%7} 天是 ${result}` },
                            { desc: "得出结论", detail: `再过 ${total} 天是 ${result}。` }
                        ]
                    };
                }
            ],
            4: [
                // 1. 混合运算应用
                () => {
                    const num1 = Math.floor(Math.random() * 20) + 10;
                    const num2 = Math.floor(Math.random() * 5) + 2;
                    const num3 = Math.floor(Math.random() * 10) + 5;
                    const result = num1 * num2 + num3;
                    return {
                        question: `超市里每袋苹果 ${num1} 元，妈妈买了 ${num2} 袋，又买了一盒 ${num3} 元的饼干，一共花了多少钱？`,
                        answer: result,
                        answerType: 'number',
                        type: '混合运算',
                        grade: 4,
                        hint: "先算乘法（苹果的总价），再算加法（加上饼干的价格）。",
                        solution: [
                            { desc: "计算苹果总价", detail: `${num1} × ${num2} = ${num1 * num2}` },
                            { desc: "加上饼干价格", detail: `${num1 * num2} + ${num3} = ${result}` },
                            { desc: "得出结论", detail: `一共花了 ${result} 元。` }
                        ]
                    };
                },
                // 2. 面积应用
                () => {
                    const length = Math.floor(Math.random() * 10) + 5;
                    const width = Math.floor(Math.random() * 8) + 3;
                    const area = length * width;
                    return {
                        question: `一个长方形的长是 ${length} 米，宽是 ${width} 米，它的面积是多少平方米？`,
                        answer: area,
                        answerType: 'number',
                        type: '面积问题',
                        grade: 4,
                        hint: "长方形面积 = 长 × 宽。",
                        solution: [
                            { desc: "公式应用", detail: `长方形面积 = 长 × 宽` },
                            { desc: "代入数值", detail: `${length} × ${width} = ${area}` },
                            { desc: "得出结论", detail: `面积是 ${area} 平方米。` }
                        ]
                    };
                },
                // 3. 平均数问题
                () => {
                    const num1 = Math.floor(Math.random() * 20) + 80;
                    const num2 = Math.floor(Math.random() * 20) + 80;
                    const num3 = Math.floor(Math.random() * 20) + 80;
                    const average = Math.floor((num1 + num2 + num3) / 3);
                    return {
                        question: `小明三次考试的成绩分别是 ${num1} 分、${num2} 分、${num3} 分，他的平均成绩是多少分？`,
                        answer: average,
                        answerType: 'number',
                        type: '平均数问题',
                        grade: 4,
                        hint: "平均数 = 总分数 ÷ 次数。",
                        solution: [
                            { desc: "计算总分数", detail: `${num1} + ${num2} + ${num3} = ${num1 + num2 + num3}` },
                            { desc: "计算平均数", detail: `${num1 + num2 + num3} ÷ 3 = ${average}` },
                            { desc: "得出结论", detail: `平均成绩是 ${average} 分。` }
                        ]
                    };
                }
            ],
            5: [
                // 1. 小数应用
                () => {
                    const price = (Math.random() * 5 + 10).toFixed(1);
                    const quantity = Math.floor(Math.random() * 5) + 2;
                    const total = (parseFloat(price) * quantity).toFixed(1);
                    return {
                        question: `一斤苹果 ${price} 元，妈妈买了 ${quantity} 斤，一共需要多少钱？`,
                        answer: parseFloat(total),
                        answerType: 'decimal',
                        type: '小数应用',
                        grade: 5,
                        hint: "总价 = 单价 × 数量。",
                        solution: [
                            { desc: "公式应用", detail: `总价 = 单价 × 数量` },
                            { desc: "代入计算", detail: `${price} × ${quantity} = ${total}` },
                            { desc: "得出结论", detail: `一共需要 ${total} 元。` }
                        ]
                    };
                },
                // 2. 分数应用
                () => {
                    const total = Math.floor(Math.random() * 30) + 20;
                    const fraction = 1/2;
                    const result = total * fraction;
                    return {
                        question: `一堆煤有 ${total} 吨，用去了它的 1/2，用去了多少吨？`,
                        answer: result,
                        answerType: 'number',
                        type: '分数应用',
                        grade: 5,
                        hint: "用去的数量 = 总数量 × 用去的分数。",
                        solution: [
                            { desc: "公式应用", detail: `用去的数量 = 总数量 × 1/2` },
                            { desc: "代入计算", detail: `${total} × 1/2 = ${result}` },
                            { desc: "得出结论", detail: `用去了 ${result} 吨。` }
                        ]
                    };
                },
                // 3. 相遇问题
                () => {
                    const distance = Math.floor(Math.random() * 100) + 50;
                    const speed1 = Math.floor(Math.random() * 10) + 10;
                    const speed2 = Math.floor(Math.random() * 10) + 10;
                    const time = distance / (speed1 + speed2);
                    return {
                        question: `甲乙两地相距 ${distance} 千米，甲车每小时行 ${speed1} 千米，乙车每小时行 ${speed2} 千米，两车同时从两地出发相向而行，几小时后相遇？`,
                        answer: parseFloat(time.toFixed(1)),
                        answerType: 'decimal',
                        type: '相遇问题',
                        grade: 5,
                        hint: "相遇时间 = 总路程 ÷ 速度和。",
                        solution: [
                            { desc: "计算速度和", detail: `${speed1} + ${speed2} = ${speed1 + speed2} 千米/小时` },
                            { desc: "计算相遇时间", detail: `${distance} ÷ ${speed1 + speed2} ≈ ${time.toFixed(1)} 小时` },
                            { desc: "得出结论", detail: `${time.toFixed(1)} 小时后相遇。` }
                        ]
                    };
                }
            ]
        };

        const gradeTemplates = templates[grade] || templates[1];
        const template = gradeTemplates[Math.floor(Math.random() * gradeTemplates.length)];
        return template();
    }

    // 六年级应用题模板库
    static generateGrade6Application() {
        const templates = [
            // 1. 百分数：折扣计算
            () => {
                const originalPrice = Math.floor(Math.random() * 40 + 10) * 10; // 100-500元
                const discount = Math.floor(Math.random() * 3 + 6); // 6-9折
                const answer = originalPrice * (discount / 10);
                return {
                    question: `一件衣服原价 ${originalPrice} 元，现在店庆打 ${discount} 折出售，请问现价是多少元？`,
                    answer: answer,
                    answerType: 'number',
                    type: '百分数应用',
                    grade: 6,
                    hint: "\"打几折\"代表现价是原价的十分之几，例如八折就是原价 × 0.8。",
                    solution: [
                        { desc: "识别折数", detail: `${discount}折 即为原价的 ${discount/10}` },
                        { desc: "列式计算", detail: `${originalPrice} × ${discount/10} = ${answer}` },
                        { desc: "得出结论", detail: `现价为 ${answer} 元。` }
                    ]
                };
            },
            // 2. 百分数：纳税/利息
            () => {
                const principal = Math.floor(Math.random() * 5 + 1) * 1000; // 1000-5000元
                const rate = 2.25; // 固定利率
                const year = 2;
                const interest = principal * (rate / 100) * year;
                return {
                    question: `小红把 ${principal} 元压岁钱存入银行，年利率为 ${rate}%，存期 ${year} 年。到期时可得利息多少元？`,
                    answer: interest,
                    answerType: 'number',
                    type: '利息计算',
                    grade: 6,
                    hint: "利息 = 本金 × 利率 × 存期。",
                    solution: [
                        { desc: "公式代入", detail: `利息 = ${principal} × ${rate}% × ${year}` },
                        { desc: "计算过程", detail: `${principal} × 0.0225 × 2 = ${interest}` },
                        { desc: "得出结果", detail: `利息总计 ${interest} 元。` }
                    ]
                };
            },
            // 3. 比例：按比例分配
            () => {
                const ratioA = 2, ratioB = 3;
                const unit = Math.floor(Math.random() * 10 + 5);
                const total = (ratioA + ratioB) * unit;
                const partB = ratioB * unit;
                return {
                    question: `一种药水是药粉和水按照 ${ratioA}:${ratioB} 的比配制而成的。现在有药水 ${total} 千克，需要水多少千克？`,
                    answer: partB,
                    answerType: 'number',
                    type: '比的应用',
                    grade: 6,
                    hint: "先求出一共有多少份，再看水占总份数的几分之几。",
                    solution: [
                        { desc: "计算总份数", detail: `总份数 = ${ratioA} + ${ratioB} = ${ratioA + ratioB}` },
                        { desc: "计算每份重量", detail: `每份重量 = ${total} ÷ ${ratioA + ratioB} = ${unit}` },
                        { desc: "计算水的重量", detail: `水的重量 = ${ratioB} × ${unit} = ${partB}` }
                    ]
                };
            },
            // 4. 分数：工程问题
            () => {
                const timeA = Math.floor(Math.random() * 5 + 3); // 3-8天
                const timeB = Math.floor(Math.random() * 5 + 3); // 3-8天
                const totalWork = 1;
                const rateA = 1 / timeA;
                const rateB = 1 / timeB;
                const combinedRate = rateA + rateB;
                const answer = 1 / combinedRate;
                return {
                    question: `一项工程，甲单独做需要 ${timeA} 天完成，乙单独做需要 ${timeB} 天完成。如果甲乙合作，需要多少天完成？`,
                    answer: parseFloat(answer.toFixed(1)),
                    answerType: 'decimal',
                    type: '工程问题',
                    grade: 6,
                    hint: "将总工作量看作单位1，工作时间=工作量÷工作效率。",
                    solution: [
                        { desc: "计算工作效率", detail: `甲的效率 = 1/${timeA}，乙的效率 = 1/${timeB}` },
                        { desc: "计算合作效率", detail: `合作效率 = 1/${timeA} + 1/${timeB} = ${combinedRate.toFixed(3)}` },
                        { desc: "计算合作时间", detail: `合作时间 = 1 ÷ ${combinedRate.toFixed(3)} ≈ ${answer.toFixed(1)} 天` }
                    ]
                };
            },
            // 5. 几何：圆柱体积
            () => {
                const radius = Math.floor(Math.random() * 5 + 2); // 2-6cm
                const height = Math.floor(Math.random() * 8 + 5); // 5-12cm
                const volume = Math.PI * radius * radius * height;
                return {
                    question: `一个圆柱的底面半径是 ${radius} 厘米，高是 ${height} 厘米，求它的体积。(π取3.14)`,
                    answer: Math.round(volume),
                    answerType: 'number',
                    type: '圆柱体积',
                    grade: 6,
                    hint: "圆柱体积 = π × 半径² × 高。",
                    solution: [
                        { desc: "公式代入", detail: `体积 = 3.14 × ${radius}² × ${height}` },
                        { desc: "计算过程", detail: `3.14 × ${radius*radius} × ${height} = ${Math.round(volume)}` },
                        { desc: "得出结果", detail: `圆柱体积约为 ${Math.round(volume)} 立方厘米。` }
                    ]
                };
            },
            // 6. 百分数：浓度问题
            () => {
                const solution = Math.floor(Math.random() * 200 + 100); // 100-300g
                const concentration = Math.floor(Math.random() * 20 + 10); // 10-30%
                const salt = solution * (concentration / 100);
                return {
                    question: `有一杯 ${solution} 克的盐水，浓度为 ${concentration}%，请问盐水中含盐多少克？`,
                    answer: salt,
                    answerType: 'number',
                    type: '浓度问题',
                    grade: 6,
                    hint: "盐的质量 = 盐水质量 × 浓度。",
                    solution: [
                        { desc: "公式代入", detail: `盐的质量 = ${solution} × ${concentration}%` },
                        { desc: "计算过程", detail: `${solution} × 0.${concentration} = ${salt}` },
                        { desc: "得出结果", detail: `盐水中含盐 ${salt} 克。` }
                    ]
                };
            },
            // 7. 比例：比例尺
            () => {
                const scale = 100000;
                const mapDistance = Math.floor(Math.random() * 5 + 1) / 10; // 0.1-0.5cm
                const actualDistance = mapDistance * scale / 100000;
                return {
                    question: `在比例尺为 1:${scale} 的地图上，量得两地距离为 ${mapDistance} 厘米，实际距离是多少千米？`,
                    answer: actualDistance,
                    answerType: 'number',
                    type: '比例尺应用',
                    grade: 6,
                    hint: "实际距离 = 图上距离 × 比例尺分母 ÷ 100000（转换为千米）。",
                    solution: [
                        { desc: "公式代入", detail: `实际距离 = ${mapDistance} × ${scale} ÷ 100000` },
                        { desc: "计算过程", detail: `${mapDistance} × ${scale} = ${mapDistance * scale} 厘米 = ${actualDistance} 千米` },
                        { desc: "得出结果", detail: `实际距离为 ${actualDistance} 千米。` }
                    ]
                };
            },
            // 8. 分数：行程问题
            () => {
                const distance = Math.floor(Math.random() * 100) + 50; // 50-150km
                const speed = Math.floor(Math.random() * 30 + 40); // 40-70km/h
                const time = distance / speed;
                return {
                    question: `一辆汽车从甲地开往乙地，全程 ${distance} 千米，平均速度为每小时 ${speed} 千米，需要多少小时到达？`,
                    answer: parseFloat(time.toFixed(1)),
                    answerType: 'decimal',
                    type: '行程问题',
                    grade: 6,
                    hint: "时间 = 路程 ÷ 速度。",
                    solution: [
                        { desc: "公式代入", detail: `时间 = ${distance} ÷ ${speed}` },
                        { desc: "计算过程", detail: `${distance} ÷ ${speed} ≈ ${time.toFixed(1)}` },
                        { desc: "得出结果", detail: `需要约 ${time.toFixed(1)} 小时到达。` }
                    ]
                };
            },
            // 9. 百分数：增长率
            () => {
                const lastYear = Math.floor(Math.random() * 50 + 50); // 50-100万
                const growthRate = Math.floor(Math.random() * 20 + 5); // 5-25%
                const thisYear = lastYear * (1 + growthRate / 100);
                return {
                    question: `某公司去年的销售额是 ${lastYear} 万元，今年比去年增长了 ${growthRate}%，今年的销售额是多少万元？`,
                    answer: thisYear,
                    answerType: 'number',
                    type: '增长率问题',
                    grade: 6,
                    hint: "今年销售额 = 去年销售额 × (1 + 增长率)。",
                    solution: [
                        { desc: "公式应用", detail: `今年销售额 = ${lastYear} × (1 + ${growthRate}%)` },
                        { desc: "计算过程", detail: `${lastYear} × 1.${growthRate} = ${thisYear}` },
                        { desc: "得出结论", detail: `今年销售额为 ${thisYear} 万元。` }
                    ]
                };
            },
            // 10. 几何：圆锥体积
            () => {
                const radius = Math.floor(Math.random() * 4 + 3); // 3-6cm
                const height = Math.floor(Math.random() * 6 + 6); // 6-11cm
                const volume = (1/3) * Math.PI * radius * radius * height;
                return {
                    question: `一个圆锥的底面半径是 ${radius} 厘米，高是 ${height} 厘米，求它的体积。(π取3.14)`,
                    answer: Math.round(volume),
                    answerType: 'number',
                    type: '圆锥体积',
                    grade: 6,
                    hint: "圆锥体积 = 1/3 × π × 半径² × 高。",
                    solution: [
                        { desc: "公式代入", detail: `体积 = 1/3 × 3.14 × ${radius}² × ${height}` },
                        { desc: "计算过程", detail: `1/3 × 3.14 × ${radius*radius} × ${height} ≈ ${Math.round(volume)}` },
                        { desc: "得出结果", detail: `圆锥体积约为 ${Math.round(volume)} 立方厘米。` }
                    ]
                };
            }
        ];

        const template = templates[Math.floor(Math.random() * templates.length)];
        return template();
    }

    // 简易方程生成
    static generateEquation(grade) {
        const equationTypes = ['basic_add', 'basic_sub', 'basic_mul', 'complex', 'bracket'];
        const type = equationTypes[Math.floor(Math.random() * equationTypes.length)];
        
        let question, answer, hint, solution;
        
        switch (type) {
            case 'basic_add': {
                const x1 = Math.floor(Math.random() * 10) + 1;
                const a1 = Math.floor(Math.random() * 10) + 1;
                const c1 = x1 + a1;
                question = `x + ${a1} = ${c1}`;
                answer = x1;
                hint = "解方程：x = c - a";
                solution = [
                    { desc: "解：设 x 为未知数", detail: "根据方程 x + a = c" },
                    { desc: "移项", detail: `x = ${c1} - ${a1}` },
                    { desc: "计算", detail: `x = ${x1}` }
                ];
                break;
            }
                
            case 'basic_sub': {
                const x2 = Math.floor(Math.random() * 10) + 1;
                const a2 = Math.floor(Math.random() * 10) + 1;
                const c2 = x2 - a2;
                if (c2 < 0) {
                    const temp = x2;
                    x2 = a2;
                    a2 = temp;
                }
                question = `x - ${a2} = ${x2 - a2}`;
                answer = x2;
                hint = "解方程：x = c + a";
                solution = [
                    { desc: "解：设 x 为未知数", detail: "根据方程 x - a = c" },
                    { desc: "移项", detail: `x = ${x2 - a2} + ${a2}` },
                    { desc: "计算", detail: `x = ${x2}` }
                ];
                break;
            }
                
            case 'basic_mul': {
                const a3 = Math.floor(Math.random() * 9) + 2;
                const x3 = Math.floor(Math.random() * 10) + 1;
                const c3 = a3 * x3;
                question = `${a3}x = ${c3}`;
                answer = x3;
                hint = "解方程：x = c ÷ a";
                solution = [
                    { desc: "解：设 x 为未知数", detail: "根据方程 ax = c" },
                    { desc: "求解", detail: `x = ${c3} ÷ ${a3}` },
                    { desc: "计算", detail: `x = ${x3}` }
                ];
                break;
            }
                
            case 'complex': {
                const a4 = Math.floor(Math.random() * 9) + 2;
                const x4 = Math.floor(Math.random() * 10) + 1;
                const b4 = Math.floor(Math.random() * 20) + 5;
                const c4 = a4 * x4 + b4;
                question = `${a4}x + ${b4} = ${c4}`;
                answer = x4;
                hint = "解方程：ax + b = c，先移项，再求解";
                solution = [
                    { desc: "解：设 x 为未知数", detail: "根据方程 ax + b = c" },
                    { desc: "移项", detail: `${a4}x = ${c4} - ${b4}，即 ${a4}x = ${c4 - b4}` },
                    { desc: "求解", detail: `x = ${c4 - b4} ÷ ${a4}` },
                    { desc: "计算", detail: `x = ${x4}` }
                ];
                break;
            }
                
            case 'bracket': {
                const a5 = Math.floor(Math.random() * 9) + 2;
                const x5 = Math.floor(Math.random() * 10) + 1;
                const b5 = Math.floor(Math.random() * 5) + 1;
                const c5 = a5 * (x5 + b5);
                question = `${a5}(x + ${b5}) = ${c5}`;
                answer = x5;
                hint = "解方程：a(x + b) = c，先去括号，再求解";
                solution = [
                    { desc: "解：设 x 为未知数", detail: "根据方程 a(x + b) = c" },
                    { desc: "去括号", detail: `${a5}x + ${a5 * b5} = ${c5}` },
                    { desc: "移项", detail: `${a5}x = ${c5} - ${a5 * b5}` },
                    { desc: "求解", detail: `x = ${c5 - a5 * b5} ÷ ${a5}` },
                    { desc: "计算", detail: `x = ${x5}` }
                ];
                break;
            }
        }
        
        return {
            question,
            answer,
            answerType: 'number',
            type: '简易方程',
            grade: 5,
            hint,
            solution
        };
    }

    // 正反比例（函数）生成
    static generateFunction(grade) {
        // 正比例：y = kx
        const k = Math.floor(Math.random() * 9) + 1;
        const x = Math.floor(Math.random() * 10) + 1;
        const y = k * x;
        
        return {
            question: `已知 y 与 x 成正比例，当 x = ${x} 时，y = ${y}，求比例系数 k =`,
            answer: k,
            answerType: 'number',
            type: '正比例函数',
            grade: 6,
            kValue: k, // 直接传递k值，避免正则解析
            hint: "正比例关系：y = kx，所以 k = y ÷ x。",
            solution: [
                { desc: "确定关系", detail: "y 与 x 成正比例，所以 y = kx" },
                { desc: "代入计算", detail: `k = y ÷ x = ${y} ÷ ${x} = ${k}` },
                { desc: "验证", detail: `当 x = ${x} 时，y = ${k} × ${x} = ${y}，符合条件。` }
            ]
        };
    }

    // 统计图表题目生成
    static generateStatistics(grade) {
        const scores = Array.from({length: 10}, () => Math.floor(Math.random() * 40) + 60);
        const average = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);
        const passingCount = scores.filter(s => s >= 60).length;
        const excellentCount = scores.filter(s => s >= 90).length;
        
        const questionTypes = ['average', 'passing', 'excellent'];
        const type = questionTypes[Math.floor(Math.random() * questionTypes.length)];
        
        let question, answer, hint, solution;
        
        switch (type) {
            case 'average': {
                question = `某班10名同学的考试成绩分别是：${scores.join('、')}分，求平均分。`;
                answer = average;
                hint = "平均分 = 总分 ÷ 人数。";
                solution = [
                    { desc: "计算总分", detail: `总分 = ${scores.join(' + ')} = ${scores.reduce((a, b) => a + b, 0)}` },
                    { desc: "计算平均分", detail: `平均分 = ${scores.reduce((a, b) => a + b, 0)} ÷ 10 = ${average}` }
                ];
                break;
            }
            case 'passing': {
                question = `某班10名同学的考试成绩分别是：${scores.join('、')}分，及格（60分及以上）的有多少人？`;
                answer = passingCount;
                hint = "及格人数就是分数大于等于60分的人数。";
                solution = [
                    { desc: "找出及格分数", detail: `及格分数：${scores.filter(s => s >= 60).join('、')}` },
                    { desc: "统计人数", detail: `及格人数 = ${passingCount} 人` }
                ];
                break;
            }
            case 'excellent': {
                question = `某班10名同学的考试成绩分别是：${scores.join('、')}分，优秀（90分及以上）的有多少人？`;
                answer = excellentCount;
                hint = "优秀人数就是分数大于等于90分的人数。";
                solution = [
                    { desc: "找出优秀分数", detail: `优秀分数：${scores.filter(s => s >= 90).join('、')}` },
                    { desc: "统计人数", detail: `优秀人数 = ${excellentCount} 人` }
                ];
                break;
            }
        }
        
        return {
            question,
            answer,
            answerType: 'number',
            type: '统计图表',
            grade: 6,
            chartData: scores,
            chartType: 'bar',
            hint,
            solution
        };
    }

    // 六年级题目：比例百分数
    static generateGrade6Question() {
        const types = ['percentage', 'ratio', 'fraction_mul', 'decimal_div', 'percent_convert', 'geometry_circle', 'geometry_rect', 'geometry_square', 'equation', 'function', 'statistics', 'tf', 'choice', 'application'];
        const type = types[Math.floor(Math.random() * types.length)];

        switch (type) {
            case 'percentage': {
                const num = Math.floor(Math.random() * 100) + 1;
                const percent = Math.floor(Math.random() * 50) + 10;
                return {
                    question: `${num} 的 ${percent}% 是多少？`,
                    answer: Math.round(num * percent / 100),
                    answerType: 'number',
                    type: '百分数计算',
                    hint: '求一个数的百分之几，用乘法计算',
                    solution: [
                        { desc: "转化百分数", detail: `${percent}% = ${percent}/100 = 0.${percent}` },
                        { desc: "计算过程", detail: `${num} × ${percent}% = ${num} × ${percent/100}` },
                        { desc: "结果", detail: `答案是 ${Math.round(num * percent / 100)}` }
                    ]
                };
            }
            
            case 'ratio': {
                const a = Math.floor(Math.random() * 8) + 2;
                const b = Math.floor(Math.random() * 8) + 2;
                const multiplier = Math.floor(Math.random() * 10) + 2;
                return {
                    question: `${a}:${b} = ${a * multiplier}:?`,
                    answer: b * multiplier,
                    answerType: 'number',
                    type: '比例计算',
                    hint: '比例的前项和后项同时乘或除以相同的数（0除外），比值不变',
                    solution: [
                        { desc: "认识比例", detail: `比例 ${a}:${b}，前项扩大了 ${multiplier} 倍` },
                        { desc: "计算过程", detail: `后项也要扩大 ${multiplier} 倍：${b} × ${multiplier}` },
                        { desc: "结果", detail: `答案是 ${b * multiplier}` }
                    ]
                };
            }
            
            case 'fraction_mul': {
                const num1 = Math.floor(Math.random() * 8) + 1;
                const den1 = Math.floor(Math.random() * 8) + 2;
                const num2 = Math.floor(Math.random() * 8) + 1;
                const den2 = Math.floor(Math.random() * 8) + 2;
                const mulNum = num1 * num2;
                const mulDen = den1 * den2;
                const simplified3 = this.simplifyFraction(mulNum, mulDen);
                return {
                    question: `${num1}/${den1} × ${num2}/${den2} =`,
                    answer: simplified3.numerator + '/' + simplified3.denominator,
                    answerType: 'fraction',
                    type: '分数乘法',
                    hint: '分数乘分数，用分子相乘的积作分子，分母相乘的积作分母',
                    solution: [
                        { desc: "分子相乘", detail: `分子：${num1} × ${num2} = ${mulNum}` },
                        { desc: "分母相乘", detail: `分母：${den1} × ${den2} = ${mulDen}` },
                        { desc: "化简结果", detail: simplified3.numerator === mulNum ? `答案已经是 ${mulNum}/${mulDen}` : `化简：${mulNum}/${mulDen} = ${simplified3.numerator}/${simplified3.denominator}` }
                    ]
                };
            }
            
            case 'decimal_div': {
                const dividend = (Math.random() * 10 + 5).toFixed(1);
                const divisor = Math.floor(Math.random() * 5) + 2;
                const answer4 = this.preciseDecimalOperation(parseFloat(dividend), divisor, '÷');
                return {
                    question: `${dividend} ÷ ${divisor} =`,
                    answer: parseFloat(answer4.toFixed(2)),
                    answerType: 'decimal',
                    type: '小数除法',
                    hint: '小数除以整数，按照整数除法的方法计算，商的小数点要和被除数的小数点对齐',
                    solution: [
                        { desc: "按整数除", detail: `把 ${dividend} 和 ${divisor} 都看作整数计算` },
                        { desc: "对齐小数点", detail: `商的小数点要和被除数 ${dividend} 的小数点对齐` },
                        { desc: "结果", detail: `答案是 ${parseFloat(answer4.toFixed(2))}` }
                    ]
                };
            }
            
            case 'percent_convert': {
                const decimal = (Math.random() * 2).toFixed(2);
                return {
                    question: `将小数 ${decimal} 转换为百分数`,
                    answer: (parseFloat(decimal) * 100).toFixed(0) + '%',
                    answerType: 'percent',
                    type: '小数转百分数',
                    hint: '小数化成百分数，只要把小数点向右移动两位，同时在后面添上百分号',
                    solution: [
                        { desc: "移动小数点", detail: `将 ${decimal} 的小数点向右移动两位` },
                        { desc: "添加百分号", detail: `${parseFloat(decimal) * 100} 加上百分号` },
                        { desc: "结果", detail: `答案是 ${(parseFloat(decimal) * 100).toFixed(0)}%` }
                    ]
                };
            }
            
            case 'geometry_circle': {
                const circleRadius = Math.floor(Math.random() * 8) + 2;
                const circleArea = Math.round(Math.PI * circleRadius * circleRadius);
                const circlePerimeter = Math.round(2 * Math.PI * circleRadius);
                const circleType = Math.random() > 0.5 ? 'area' : 'perimeter';
                if (circleType === 'area') {
                    return {
                        question: `已知圆的半径为 ${circleRadius}，求面积 S = (π取3.14)`,
                        answer: circleArea,
                        answerType: 'number',
                        type: '圆面积',
                        grade: 6,
                        category: 'geometry',
                        shape: 'circle',
                        params: { radius: circleRadius },
                        hint: '圆的面积公式是：面积 = π × 半径²',
                        solution: [
                            { desc: "确定公式", detail: '圆面积 S = π × r²' },
                            { desc: "代入数值", detail: `S = 3.14 × ${circleRadius} × ${circleRadius}` },
                            { desc: "计算结果", detail: `S ≈ ${circleArea}` }
                        ]
                    };
                } else {
                    return {
                        question: `已知圆的半径为 ${circleRadius}，求周长 C = (π取3.14)`,
                        answer: circlePerimeter,
                        answerType: 'number',
                        type: '圆周长',
                        grade: 6,
                        category: 'geometry',
                        shape: 'circle',
                        params: { radius: circleRadius },
                        hint: '圆的周长公式是：周长 = 2 × π × 半径',
                        solution: [
                            { desc: "确定公式", detail: '圆周长 C = 2 × π × r' },
                            { desc: "代入数值", detail: `C = 2 × 3.14 × ${circleRadius}` },
                            { desc: "计算结果", detail: `C ≈ ${circlePerimeter}` }
                        ]
                    };
                }
            }
            
            case 'geometry_rect': {
                const rectW6 = Math.floor(Math.random() * 15) + 5;
                const rectH6 = Math.floor(Math.random() * 10) + 3;
                const rectArea6 = rectW6 * rectH6;
                const rectPerimeter6 = 2 * (rectW6 + rectH6);
                const rectType6 = Math.random() > 0.5 ? 'area' : 'perimeter';
                if (rectType6 === 'area') {
                    return {
                        question: `已知长方形的长为 ${rectW6}，宽为 ${rectH6}，求面积 S =`,
                        answer: rectArea6,
                        answerType: 'number',
                        type: '长方形面积',
                        grade: 6,
                        category: 'geometry',
                        shape: 'rectangle',
                        params: { width: rectW6, height: rectH6 },
                        hint: '长方形的面积公式是：面积 = 长 × 宽',
                        solution: [
                            { desc: "确定公式", detail: '长方形面积 S = 长 × 宽' },
                            { desc: "代入数值", detail: `S = ${rectW6} (长) × ${rectH6} (宽)` },
                            { desc: "计算结果", detail: `S = ${rectArea6}` }
                        ]
                    };
                } else {
                    return {
                        question: `已知长方形的长为 ${rectW6}，宽为 ${rectH6}，求周长 C =`,
                        answer: rectPerimeter6,
                        answerType: 'number',
                        type: '长方形周长',
                        grade: 6,
                        category: 'geometry',
                        shape: 'rectangle',
                        params: { width: rectW6, height: rectH6 },
                        hint: '长方形的周长公式是：周长 = (长 + 宽) × 2',
                        solution: [
                            { desc: "确定公式", detail: '长方形周长 C = (长 + 宽) × 2' },
                            { desc: "代入数值", detail: `C = (${rectW6} + ${rectH6}) × 2` },
                            { desc: "计算结果", detail: `C = ${rectW6 + rectH6} × 2 = ${rectPerimeter6}` }
                        ]
                    };
                }
            }
            
            case 'geometry_square': {
                const squareSide6 = Math.floor(Math.random() * 12) + 3;
                const squareArea6 = squareSide6 * squareSide6;
                const squarePerimeter6 = 4 * squareSide6;
                const squareType6 = Math.random() > 0.5 ? 'area' : 'perimeter';
                if (squareType6 === 'area') {
                    return {
                        question: `已知正方形的边长为 ${squareSide6}，求面积 S =`,
                        answer: squareArea6,
                        answerType: 'number',
                        type: '正方形面积',
                        grade: 6,
                        category: 'geometry',
                        shape: 'square',
                        params: { side: squareSide6 },
                        hint: '正方形的面积公式是：面积 = 边长 × 边长',
                        solution: [
                            { desc: "确定公式", detail: '正方形面积 S = 边长 × 边长' },
                            { desc: "代入数值", detail: `S = ${squareSide6} × ${squareSide6}` },
                            { desc: "计算结果", detail: `S = ${squareArea6}` }
                        ]
                    };
                } else {
                    return {
                        question: `已知正方形的边长为 ${squareSide6}，求周长 C =`,
                        answer: squarePerimeter6,
                        answerType: 'number',
                        type: '正方形周长',
                        grade: 6,
                        category: 'geometry',
                        shape: 'square',
                        params: { side: squareSide6 },
                        hint: '正方形的周长公式是：周长 = 边长 × 4',
                        solution: [
                            { desc: "确定公式", detail: '正方形周长 C = 边长 × 4' },
                            { desc: "代入数值", detail: `C = ${squareSide6} × 4` },
                            { desc: "计算结果", detail: `C = ${squarePerimeter6}` }
                        ]
                    };
                }
            }
            
            case 'tf': {
                return this.generateTFQuestion(6);
            }
            case 'choice': {
                return this.generateChoiceQuestion(6);
            }
            case 'equation': {
                return this.generateEquation(6);
            }
            case 'function': {
                return this.generateFunction(6);
            }
            case 'statistics': {
                return this.generateStatistics(6);
            }
            case 'application': {
                return this.generateGrade6Application();
            }
            default: {
                return this.generateGrade1Question(); // 安全兜底，避免递归
            }
        }
    }

    // 获取题目统计
    static getStats() {
        new MathGenerator();
        return {
            totalGenerated: MathGenerator.questionHistoryCache.size,
            history: [...MathGenerator.questionHistoryCache]
        };
    }

    // 按知识点生成题目
    static generateQuestionByType(grade, questionType) {
        let question;
        let attempts = 0;
        
        do {
            question = this.generateSpecificQuestion(grade, questionType);
            attempts++;
        } while (this.isDuplicateQuestion(question.question) && attempts < 50);
        
        this.addToHistory(question.question);
        
        return question;
    }

    // 生成特定类型的题目
    static generateSpecificQuestion(grade, questionType) {
        switch (grade) {
            case 1: {
                return this.generateGrade1ByType(questionType);
            }
            case 2: {
                return this.generateGrade2ByType(questionType);
            }
            case 3: {
                return this.generateGrade3ByType(questionType);
            }
            case 4: {
                return this.generateGrade4ByType(questionType);
            }
            case 5: {
                return this.generateGrade5ByType(questionType);
            }
            case 6: {
                return this.generateGrade6ByType(questionType);
            }
            default: {
                return this.generateGrade1Question();
            }
        }
    }

    // 一年级按类型生成
    static generateGrade1ByType(type) {
        let a, b, answer;
        const max = this.difficultySettings.addition.max;
        
        switch (type) {
            case 'addition': {
                a = Math.floor(Math.random() * max) + 1;
                b = Math.floor(Math.random() * (max - a + 1)) + 1;
                answer = a + b;
                return {
                    question: `${a} + ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: `${max}以内加法`,
                    grade: 1
                };
            }
            case 'subtraction': {
                a = Math.floor(Math.random() * max) + 1;
                b = Math.floor(Math.random() * a) + 1;
                answer = a - b;
                return {
                    question: `${a} - ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: `${max}以内减法`,
                    grade: 1
                };
            }
            default: {
                return this.generateGrade1Question();
            }
        }
    }

    // 二年级按类型生成
    static generateGrade2ByType(type) {
        let a, b, answer;
        const max = this.difficultySettings.multiplication.max;
        
        switch (type) {
            case 'multiplication': {
                a = Math.floor(Math.random() * max) + 1;
                b = Math.floor(Math.random() * max) + 1;
                answer = a * b;
                return {
                    question: `${a} × ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: `${max}以内乘法`,
                    grade: 2
                };
            }
            case 'division': {
                b = Math.floor(Math.random() * max) + 1;
                answer = Math.floor(Math.random() * max) + 1;
                a = b * answer;
                return {
                    question: `${a} ÷ ${b} =`,
                    answer: answer,
                    answerType: 'number',
                    type: `${max}以内除法`,
                    grade: 2
                };
            }
            default: {
                return this.generateGrade2Question();
            }
        }
    }

    // 三年级按类型生成 - 支持精准题型导出
    // 参数: type - 题目类型，如 'multiplication'（乘法）、'addition'（加法）
    // 返回: 题目对象，包含 question、answer、answerType、type、grade
    static generateGrade3ByType(type) {
        // 乘法题型：两位数乘一位数
        if (type === 'multiplication') {
            // 生成两位数（10-99）
            const a = Math.floor(Math.random() * 90) + 10;
            // 生成一位数（1-9）
            const b = Math.floor(Math.random() * 9) + 1;
            // 返回乘法题目对象
            return { question: `${a} × ${b} =`, answer: a * b, answerType: 'number', type: '乘法练习', grade: 3 };
        }
        // 加法题型：三位数加法
        if (type === 'addition') {
            // 生成三位数（100-899）
            const a = Math.floor(Math.random() * 800) + 100;
            const b = Math.floor(Math.random() * 800) + 100;
            // 返回加法题目对象
            return { question: `${a} + ${b} =`, answer: a + b, answerType: 'number', type: '三位数加法', grade: 3 };
        }
        // 其他类型：返回默认随机题目
        return this.generateGrade3Question();
    }

    // 四年级按类型生成
    static generateGrade4ByType(type) {
        switch (type) {
            case 'mixed':
            case 'decimal': {
                return this.generateGrade4Question();
            }
            default: {
                return this.generateGrade4Question();
            }
        }
    }

    // 五年级按类型生成 - 精准对接测试ID
    // 参数: type - 题目类型，如 'decimal'（小数）、'fraction_add'（分数加法）
    // 返回: 题目对象，包含 question、answer、answerType、type、grade
    static generateGrade5ByType(type) {
        // 小数加法题型：生成一位小数加法
        if (type === 'decimal' || type === 'decimal_add') {
            // 生成0.0-9.9之间的一位小数
            const a = parseFloat((Math.random() * 10).toFixed(1));
            const b = parseFloat((Math.random() * 10).toFixed(1));
            // 计算结果并保留一位小数
            return { question: `${a.toFixed(1)} + ${b.toFixed(1)} =`, answer: parseFloat((a + b).toFixed(1)), answerType: 'number', type: '小数加法', grade: 5 };
        }
        // 分数加法题型：生成同分母分数加法
        if (type === 'fraction_add') {
            // 生成分母（2-6）
            const den = Math.floor(Math.random() * 5) + 2;
            // 分子固定为1，便于计算
            const n1 = 1, n2 = 1;
            // 返回分数加法题目对象，答案类型为 'string'（分数用字符串表示）
            return { question: `${n1}/${den} + ${n2}/${den} =`, answer: `${n1+n2}/${den}`, answerType: 'string', type: '分数加法', grade: 5 };
        }
        // 其他类型：返回默认随机题目
        return this.generateGrade5Question();
    }

    // 六年级按类型生成
    static generateGrade6ByType(type) {
        switch (type) {
            case 'percentage':
            case 'ratio':
            case 'fraction_mul':
            case 'decimal_div':
            case 'percent_convert': {
                return this.generateGrade6Question();
            }
            default: {
                return this.generateGrade6Question();
            }
        }
    }

    // 获取各年级可用的知识点类型
    static getAvailableTypes(grade) {
        const types = {
            1: [
                { id: 'addition', name: '加法练习', icon: '➕' },
                { id: 'subtraction', name: '减法练习', icon: '➖' }
            ],
            2: [
                { id: 'multiplication', name: '乘法练习', icon: '✖️' },
                { id: 'division', name: '除法练习', icon: '➗' }
            ],
            3: [
                { id: 'multiplication', name: '两位数乘一位数', icon: '✖️' },
                { id: 'division', name: '除数是一位数的除法', icon: '➗' },
                { id: 'decimal', name: '小数加法', icon: '🔢' },
                { id: 'addition', name: '三位数加法', icon: '➕' },
                { id: 'subtraction', name: '三位数减法', icon: '➖' }
            ],
            4: [
                { id: 'mixed', name: '四则混合运算', icon: '🧮' },
                { id: 'decimal', name: '小数运算', icon: '🔢' }
            ],
            5: [
                { id: 'decimal_add', name: '小数加法', icon: '🔢' },
                { id: 'decimal_sub', name: '小数减法', icon: '🔢' },
                { id: 'decimal_mul', name: '小数乘法', icon: '✖️' },
                { id: 'fraction_add', name: '分数加法', icon: '➕' },
                { id: 'fraction_sub', name: '分数减法', icon: '➖' },
                { id: 'percent', name: '百分数', icon: '💯' },
                { id: 'geometry_rect', name: '长方形面积周长', icon: '⬜' },
                { id: 'geometry_square', name: '正方形面积周长', icon: '⬛' },
                { id: 'geometry_triangle', name: '三角形面积', icon: '🔺' }
            ],
            6: [
                { id: 'percentage', name: '百分数计算', icon: '💯' },
                { id: 'ratio', name: '比例计算', icon: '⚖️' },
                { id: 'fraction_mul', name: '分数乘法', icon: '✖️' },
                { id: 'decimal_div', name: '小数除法', icon: '➗' },
                { id: 'percent_convert', name: '百分数转换', icon: '🔄' },
                { id: 'geometry_circle', name: '圆面积周长', icon: '⭕' },
                { id: 'geometry_rect', name: '长方形面积周长', icon: '⬜' },
                { id: 'geometry_square', name: '正方形面积周长', icon: '⬛' },
                { id: 'equation', name: '简易方程', icon: '📐' },
                { id: 'function', name: '正比例函数', icon: '📈' },
                { id: 'statistics', name: '统计图表', icon: '📊' },
                { id: 'tf', name: '判断题', icon: '✅' },
                { id: 'choice', name: '选择题', icon: '❓' },
                { id: 'application', name: '应用题', icon: '📝' }
            ]
        };
        return types[grade] || types[1];
    }
}

// 导出MathGenerator类
window.MathGenerator = MathGenerator;