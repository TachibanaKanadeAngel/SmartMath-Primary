// 小学数学练习小程序 - 主要JavaScript逻辑
// 功能：多账号管理、用户数据存储、PWA更新通知、能力评估

// 多账号管理模块
// 功能：管理多个用户档案，支持创建、删除、切换档案
const ProfileManager = {
    // 获取当前激活的档案ID
    // 返回: 档案ID字符串，默认为'default'
    getCurrentProfileId: () => {
        return localStorage.getItem('currentProfileId') || 'default';
    },
    // 设置当前激活的档案ID
    // 参数: id - 档案ID
    setCurrentProfileId: (id) => {
        localStorage.setItem('currentProfileId', id);
    },
    // 获取所有用户档案
    // 返回: 档案数组，如果没有档案则创建默认档案
    getAllProfiles: () => {
        // 从localStorage读取档案列表
        const profiles = JSON.parse(localStorage.getItem('mathProfiles') || '[]');
        // 如果没有档案，创建默认档案
        if (profiles.length === 0) {
            // 创建默认档案对象
            profiles.push({
                id: 'default',
                name: '小学生',
                avatar: '小',
                createdAt: Date.now()
            });
            // 保存到localStorage
            localStorage.setItem('mathProfiles', JSON.stringify(profiles));
        }
        return profiles;
    },
    // 创建新用户档案
    // 参数: name - 用户名称
    // 返回: 新档案的ID
    createProfile: (name) => {
        // 获取现有档案列表
        const profiles = ProfileManager.getAllProfiles();
        // 生成唯一ID（使用时间戳）
        const newId = 'profile_' + Date.now();
        // 使用用户名的第一个字符作为头像
        const avatar = name.charAt(0);
        // 添加新档案到列表
        profiles.push({
            id: newId,
            name: name,
            avatar: avatar,
            createdAt: Date.now()
        });
        // 保存更新后的档案列表
        localStorage.setItem('mathProfiles', JSON.stringify(profiles));
        return newId;
    },
    // 删除用户档案
    // 参数: id - 档案ID
    // 返回: 是否删除成功（默认档案不能删除）
    deleteProfile: (id) => {
        // 默认档案不能删除
        if (id === 'default') return false;
        // 获取现有档案列表
        let profiles = ProfileManager.getAllProfiles();
        // 从列表中移除指定档案
        profiles = profiles.filter(p => p.id !== id);
        // 保存更新后的档案列表
        localStorage.setItem('mathProfiles', JSON.stringify(profiles));
        
        // 删除该档案的所有相关数据
        localStorage.removeItem('mathUser_' + id);           // 用户数据
        localStorage.removeItem('mistake_list_' + id);         // 错题本
        localStorage.removeItem('questionHistory_' + id);        // 题目历史
        localStorage.removeItem('dailyRecords_' + id);           // 每日记录
        localStorage.removeItem('lastStudyDate_' + id);         // 最后学习日期
        
        // 如果删除的是当前档案，切换到默认
        if (ProfileManager.getCurrentProfileId() === id) {
            ProfileManager.setCurrentProfileId('default');
        }
        return true;
    },
    getProfileKey: (key) => {
        const profileId = ProfileManager.getCurrentProfileId();
        return profileId === 'default' ? key : `${key}_${profileId}`;
    }
};

// 全局变量
let currentUser = {
    name: '小学生',
    currentGrade: 1,
    totalQuestions: 0,
    correctAnswers: 0,
    totalStars: 0,
    todayQuestions: 0,
    todayCorrect: 0,
    studyStreak: 0
};

document.addEventListener('DOMContentLoaded', function() {
    loadUserData();
    updateDashboard();
    initializeAnimations();
});

// 加载用户数据
function loadUserData() {
    const storageKey = ProfileManager.getProfileKey('mathPracticeUser');
    const savedData = localStorage.getItem(storageKey);
    if (savedData) {
        currentUser = { ...currentUser, ...JSON.parse(savedData) };
    }
    
    const lastStudyDateKey = ProfileManager.getProfileKey('lastStudyDate');
    const lastStudyDate = localStorage.getItem(lastStudyDateKey);
    const today = new Date();
    const todayStr = today.toDateString();
    
    if (lastStudyDate !== todayStr) {
        if (lastStudyDate) {
            const lastDate = new Date(lastStudyDate);
            const diffTime = today.getTime() - lastDate.getTime();
            const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
            
            if (diffDays === 1) {
                currentUser.studyStreak = (currentUser.studyStreak || 0) + 1;
            } else {
                currentUser.studyStreak = 0;
            }
        } else {
            // 第一次使用，设置连胜天数为1
            currentUser.studyStreak = 1;
        }
        
        currentUser.todayQuestions = 0;
        currentUser.todayCorrect = 0;
        localStorage.setItem(lastStudyDateKey, todayStr);
        saveUserData();
    }
    
    updateProfileDisplay();
}

// 保存用户数据
function saveUserData() {
    const storageKey = ProfileManager.getProfileKey('mathPracticeUser');
    localStorage.setItem(storageKey, JSON.stringify(currentUser));
}

// 更新导航栏档案显示
function updateProfileDisplay() {
    const profiles = ProfileManager.getAllProfiles();
    const currentId = ProfileManager.getCurrentProfileId();
    const currentProfile = profiles.find(p => p.id === currentId) || profiles[0];
    
    const avatarEl = document.getElementById('profileAvatar');
    const nameEl = document.getElementById('profileName');
    
    if (avatarEl) {
        avatarEl.textContent = currentProfile.avatar;
    }
    if (nameEl) {
        nameEl.textContent = currentProfile.name;
    }
}

// 更新仪表板
function updateDashboard() {
    // 更新今日练习题目数
    const todayQuestionsEl = document.getElementById('todayQuestions');
    if (todayQuestionsEl) {
        todayQuestionsEl.textContent = currentUser.todayQuestions;
    }
    
    // 更新正确率
    const accuracy = currentUser.todayQuestions > 0 ? 
        Math.round((currentUser.todayCorrect / currentUser.todayQuestions) * 100) : 0;
    const accuracyRateEl = document.getElementById('accuracyRate');
    if (accuracyRateEl) {
        accuracyRateEl.textContent = accuracy + '%';
    }
    
    // 更新总星星数
    const totalStarsEl = document.getElementById('totalStars');
    if (totalStarsEl) {
        totalStarsEl.textContent = Math.floor(currentUser.totalStars || 0);
    }
    
    // 更新错题本统计
    if (window.mathApp && window.mathApp.MistakeManager) {
        const stats = window.mathApp.MistakeManager.getStats();
        const mistakeCountEl = document.getElementById('mistakeCount');
        const mistakePriorityEl = document.getElementById('mistakePriority');
        
        if (mistakeCountEl) {
            mistakeCountEl.textContent = stats.total;
        }
        if (mistakePriorityEl) {
            if (stats.highPriority > 0) {
                mistakePriorityEl.textContent = `${stats.highPriority}道重点`;
            } else if (stats.total > 0) {
                mistakePriorityEl.textContent = `${stats.total}道待攻克`;
            } else {
                mistakePriorityEl.textContent = '暂无错题';
            }
        }
    }
}

// 初始化动画
function initializeAnimations() {
    // 年级卡片入场动画
    anime({
        targets: '.grade-card',
        translateY: [50, 0],
        opacity: [0, 1],
        delay: anime.stagger(100),
        duration: 800,
        easing: 'easeOutExpo'
    });

    // 统计卡片动画
    anime({
        targets: '.stat-card, .bg-gradient-to-br',
        scale: [0.9, 1],
        opacity: [0, 1],
        delay: anime.stagger(150, {start: 300}),
        duration: 600,
        easing: 'easeOutBack'
    });
}

// 选择年级
function selectGrade(grade) {
    currentUser.currentGrade = grade;
    saveUserData();
    
    // 添加选中效果
    document.querySelectorAll('.grade-card').forEach(card => {
        card.classList.remove('ring-4', 'ring-blue-400');
    });
    
    event.target.closest('.grade-card').classList.add('ring-4', 'ring-blue-400');
    
    // 显示确认对话框
    showGradeConfirm(grade);
}

// 显示年级确认对话框
function showGradeConfirm(grade) {
    const gradeNames = ['', '一年级', '二年级', '三年级', '四年级', '五年级', '六年级'];
    const gradeEmojis = ['', '🌱', '🌿', '🌸', '🌺', '🌻', '🌳'];
    
    // 获取该年级可用的知识点类型
    const availableTypes = window.MathGenerator ? window.MathGenerator.getAvailableTypes(grade) : [];
    let typesHtml = '';
    if (availableTypes.length > 0) {
        typesHtml = `
            <div class="mb-4">
                <label class="block text-gray-700 font-medium mb-2">知识点选择</label>
                <div class="grid grid-cols-2 gap-2" id="knowledgeTypes">
                    <button onclick="selectKnowledgeType('all', this)" class="knowledge-btn active bg-purple-500 text-white py-2 px-4 rounded-lg font-medium transition-all">
                        全部知识点
                    </button>
                    ${availableTypes.map(t => `
                        <button onclick="selectKnowledgeType('${t.id}', this)" class="knowledge-btn bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-all">
                            ${t.icon} ${t.name}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white rounded-3xl p-8 max-w-lg mx-4 transform scale-0" id="confirmModal">
            <div class="text-center">
                <div class="text-6xl mb-4">${gradeEmojis[grade]}</div>
                <h3 class="text-2xl font-bold text-gray-800 mb-2">${gradeNames[grade]}练习设置</h3>
                
                <div class="text-left mb-6 max-h-80 overflow-y-auto">
                    ${typesHtml}
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 font-medium mb-2">练习模式</label>
                        <div class="grid grid-cols-3 gap-2">
                            <button onclick="selectMode('quick', this)" class="mode-btn active bg-blue-500 text-white py-2 px-4 rounded-lg font-medium transition-all">
                                速测<br><span class="text-xs">10题</span>
                            </button>
                            <button onclick="selectMode('normal', this)" class="mode-btn bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-all">
                                常规<br><span class="text-xs">20题</span>
                            </button>
                            <button onclick="selectMode('challenge', this)" class="mode-btn bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-all">
                                挑战<br><span class="text-xs">30题</span>
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 font-medium mb-2">题目数量</label>
                        <input type="range" id="questionCount" min="5" max="50" value="10" 
                               class="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                               oninput="updateQuestionCount(this.value)">
                        <div class="flex justify-between text-sm text-gray-500 mt-1">
                            <span>5题</span>
                            <span id="questionCountDisplay" class="font-bold text-blue-600">10题</span>
                            <span>50题</span>
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label class="block text-gray-700 font-medium mb-2">特殊模式</label>
                        <div class="grid grid-cols-3 gap-2">
                            <button onclick="selectSpecialMode('normal', this)" class="special-btn active bg-green-500 text-white py-2 px-4 rounded-lg font-medium transition-all">
                                普通练习
                            </button>
                            <button onclick="selectSpecialMode('mistake', this)" class="special-btn bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-all">
                                错题重练
                            </button>
                            <button onclick="selectSpecialMode('timer', this)" class="special-btn bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-all">
                                ⏱️ 计时挑战
                            </button>
                        </div>
                    </div>
                    
                    <div class="mb-4" id="timerSettings" style="display: none;">
                        <label class="block text-gray-700 font-medium mb-2">计时设置</label>
                        <div class="grid grid-cols-3 gap-2">
                            <button onclick="selectTimerMode(60, this)" class="timer-btn active bg-orange-500 text-white py-2 px-4 rounded-lg font-medium transition-all">
                                1分钟
                            </button>
                            <button onclick="selectTimerMode(180, this)" class="timer-btn bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-all">
                                3分钟
                            </button>
                            <button onclick="selectTimerMode(300, this)" class="timer-btn bg-gray-100 text-gray-700 py-2 px-4 rounded-lg font-medium hover:bg-gray-200 transition-all">
                                5分钟
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="flex space-x-4">
                    <button onclick="closeModal()" class="flex-1 bg-gray-200 text-gray-800 py-3 px-6 rounded-xl font-medium hover:bg-gray-300 transition-colors">
                        取消
                    </button>
                    <button onclick="generatePrintPaper(${grade})" class="flex-1 bg-gray-500 text-white py-3 px-6 rounded-xl font-medium hover:bg-gray-600 transition-colors">
                        🖨️ 打印试卷
                    </button>
                    <button onclick="startPracticeWithSettings(${grade})" class="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-xl font-medium hover:from-blue-600 hover:to-purple-700 transition-all">
                        开始练习
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    anime({
        targets: '#confirmModal',
        scale: [0, 1],
        duration: 300,
        easing: 'easeOutBack'
    });
}

let selectedMode = 'quick';
let selectedSpecialMode = 'normal';
let selectedKnowledgeType = 'all';

function selectKnowledgeType(type, btn) {
    selectedKnowledgeType = type;
    document.querySelectorAll('.knowledge-btn').forEach(b => {
        b.classList.remove('active', 'bg-purple-500', 'text-white');
        b.classList.add('bg-gray-100', 'text-gray-700');
    });
    btn.classList.remove('bg-gray-100', 'text-gray-700');
    btn.classList.add('active', 'bg-purple-500', 'text-white');
}

function selectMode(mode, btn) {
    selectedMode = mode;
    document.querySelectorAll('.mode-btn').forEach(b => {
        b.classList.remove('active', 'bg-blue-500', 'text-white');
        b.classList.add('bg-gray-100', 'text-gray-700');
    });
    btn.classList.remove('bg-gray-100', 'text-gray-700');
    btn.classList.add('active', 'bg-blue-500', 'text-white');
    
    const counts = { quick: 10, normal: 20, challenge: 30 };
    document.getElementById('questionCount').value = counts[mode];
    updateQuestionCount(counts[mode]);
}

function selectSpecialMode(mode, btn) {
    selectedSpecialMode = mode;
    document.querySelectorAll('.special-btn').forEach(b => {
        b.classList.remove('active', 'bg-green-500', 'text-white');
        b.classList.add('bg-gray-100', 'text-gray-700');
    });
    btn.classList.remove('bg-gray-100', 'text-gray-700');
    btn.classList.add('active', 'bg-green-500', 'text-white');
    
    // 显示/隐藏计时设置
    const timerSettings = document.getElementById('timerSettings');
    if (timerSettings) {
        timerSettings.style.display = mode === 'timer' ? 'block' : 'none';
    }
}

let selectedTimerSeconds = 60;

function selectTimerMode(seconds, btn) {
    selectedTimerSeconds = seconds;
    document.querySelectorAll('.timer-btn').forEach(b => {
        b.classList.remove('active', 'bg-orange-500', 'text-white');
        b.classList.add('bg-gray-100', 'text-gray-700');
    });
    btn.classList.remove('bg-gray-100', 'text-gray-700');
    btn.classList.add('active', 'bg-orange-500', 'text-white');
}

function updateQuestionCount(value) {
    document.getElementById('questionCountDisplay').textContent = value + '题';
}

function startPracticeWithSettings(grade) {
    const questionCount = document.getElementById('questionCount').value;
    const isMistakeMode = selectedSpecialMode === 'mistake';
    const isTimerMode = selectedSpecialMode === 'timer';
    const knowledgeType = selectedKnowledgeType || 'all';
    const timerSeconds = isTimerMode ? selectedTimerSeconds : 0;
    saveUserData();
    window.location.href = `practice.html?grade=${grade}&count=${questionCount}&mistake=${isMistakeMode}&type=${knowledgeType}&timer=${timerSeconds}`;
}

// 关闭对话框
function closeModal() {
    const modal = document.querySelector('.fixed.inset-0');
    if (modal) {
        anime({
            targets: modal.querySelector('div > div'),
            scale: [1, 0],
            duration: 200,
            easing: 'easeInBack',
            complete: () => modal.remove()
        });
    }
}

// 开始练习
function startPractice(grade) {
    saveUserData();
    window.location.href = `practice.html?grade=${grade}`;
}

// 快速开始
function quickStart() {
    const recommendedGrade = currentUser.currentGrade || 1;
    startPractice(recommendedGrade);
}

function generatePrintPaper(grade) {
    const questionCount = document.getElementById('questionCount') ? document.getElementById('questionCount').value : 20;
    const knowledgeType = selectedKnowledgeType || 'all';
    
    const gradeNames = ['', '一年级', '二年级', '三年级', '四年级', '五年级', '六年级'];
    const questions = [];
    
    for (let i = 0; i < parseInt(questionCount); i++) {
        let q;
        if (knowledgeType !== 'all' && window.MathGenerator) {
            q = window.MathGenerator.generateQuestionByType(grade, knowledgeType);
        } else if (window.MathGenerator) {
            q = window.MathGenerator.generateQuestion(grade);
        } else {
            console.error("致命错误：MathGenerator 脚本加载失败，请检查语法错误");
            q = { question: "脚本加载错误", answer: "请检查代码" };
        }
        questions.push(q);
    }
    
    const printWindow = window.open('', '_blank');
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>${gradeNames[grade]}数学练习卷</title>
            <style>
                @page { margin: 15mm; }
                body { 
                    font-family: 'SimSun', serif; 
                    padding: 20px; 
                    max-width: 800px; 
                    margin: 0 auto;
                    line-height: 1.8;
                }
                h1 { text-align: center; margin-bottom: 10px; font-size: 24px; }
                .info { text-align: center; margin-bottom: 20px; color: #666; }
                .info span { margin: 0 20px; }
                .question { margin: 12px 0; font-size: 16px; }
                .question-num { font-weight: bold; margin-right: 10px; }
                .answer-line { 
                    display: inline-block; 
                    width: 80px; 
                    border-bottom: 1px solid #333; 
                    margin-left: 5px;
                }
                .footer { margin-top: 40px; text-align: center; color: #999; font-size: 12px; }
                .print-hint { 
                    text-align: center; 
                    color: #999; 
                    font-size: 11px; 
                    margin-bottom: 10px;
                    border: 1px dashed #ccc;
                    padding: 5px;
                }
                .answers-section {
                    margin-top: 40px;
                    padding-top: 20px;
                    border-top: 2px solid #333;
                }
                .answers-title {
                    font-size: 20px;
                    font-weight: bold;
                    text-align: center;
                    margin-bottom: 20px;
                    color: #333;
                }
                .answers-grid {
                    display: grid;
                    grid-template-columns: repeat(4, 1fr);
                    gap: 10px;
                    font-size: 14px;
                }
                .answer-item {
                    padding: 5px;
                    background: #f5f5f5;
                    border-radius: 4px;
                }
                .answer-num {
                    font-weight: bold;
                    color: #4A90E2;
                }
                .answer-value {
                    color: #333;
                }
                @media print { 
                    .print-hint { display: none; }
                    body { padding: 0; }
                    .answers-section {
                        page-break-before: always;
                    }
                }
            </style>
        </head>
        <body>
            <div class="print-hint">💡 打印提示：建议使用A4纸张，边距设置为默认或15mm</div>
            <h1>${gradeNames[grade]}数学练习卷</h1>
            <div class="info">
                <span>姓名：__________</span>
                <span>日期：__________</span>
                <span>得分：__________</span>
            </div>
            <hr>
            ${questions.map((q, i) => `
                <div class="question">
                    <span class="question-num">${i + 1}.</span>
                    ${q.question.replace('=', '')}
                    <span class="answer-line"></span>
                </div>
            `).join('')}
            
            <div class="answers-section">
                <div class="answers-title">📋 参考答案</div>
                <div class="answers-grid">
                    ${questions.map((q, i) => `
                        <div class="answer-item">
                            <span class="answer-num">${i + 1}.</span>
                            <span class="answer-value">${q.answer}</span>
                        </div>
                    `).join('')}
                </div>
            </div>
            
            <div class="footer">
                小学数学练习小程序 - 让每个孩子爱上数学
            </div>
        </body>
        </html>
    `);
    printWindow.document.close();
    
    setTimeout(() => {
        printWindow.print();
    }, 500);
    
    closeModal();
}

function addQuestionToHistory(questionObj, userAnswer, isCorrect) {
    currentUser.totalQuestions++;
    currentUser.todayQuestions++;
    
    if (isCorrect) {
        currentUser.correctAnswers++;
        currentUser.todayCorrect++;
        currentUser.totalStars += 0.1;
    }
    
    const historyKey = ProfileManager.getProfileKey('questionHistory');
    const history = JSON.parse(localStorage.getItem(historyKey) || '[]');
    
    // 判断题目类别
    let category = 'calculation';
    const type = questionObj.type || '';
    if (type.includes('圆') || type.includes('长方形') || type.includes('正方形') || type.includes('三角形')) {
        category = 'geometry';
    } else if (type.includes('混合') || type.includes('乘加') || type.includes('加乘')) {
        category = 'logic';
    } else if (type.includes('比例') || type.includes('应用')) {
        category = 'application';
    } else if (type.includes('小数') || type.includes('分数') || type.includes('百分')) {
        category = 'numberSense';
    }
    
    history.push({
        type: questionObj.type || '未知类型',
        isCorrect: isCorrect,
        timestamp: Date.now(),
        grade: currentUser.currentGrade,
        category: category
    });
    if (history.length > 500) history.shift();
    localStorage.setItem(historyKey, JSON.stringify(history));
    
    saveUserData();
    updateDashboard();
}

// 错题本管理
const MistakeManager = {
    save: (questionObj) => {
        const storageKey = ProfileManager.getProfileKey('mistake_list');
        let mistakes = JSON.parse(localStorage.getItem(storageKey) || '[]');
        const existingIndex = mistakes.findIndex(m => m.question === questionObj.question);
        
        if (existingIndex !== -1) {
            mistakes[existingIndex].wrongCount = (mistakes[existingIndex].wrongCount || 1) + 1;
            mistakes[existingIndex].lastWrongTime = new Date().getTime();
            mistakes[existingIndex].priority = MistakeManager.calculatePriority(mistakes[existingIndex]);
        } else {
            mistakes.push({ 
                ...questionObj, 
                timestamp: new Date().getTime(),
                wrongCount: 1,
                lastWrongTime: new Date().getTime(),
                priority: 100,
                reviewCount: 0
            });
        }
        localStorage.setItem(storageKey, JSON.stringify(mistakes));
    },
    
    calculatePriority: (mistake) => {
        const now = new Date().getTime();
        const hoursSinceLastWrong = (now - (mistake.lastWrongTime || mistake.timestamp)) / (1000 * 60 * 60);
        const wrongCountBonus = Math.min(mistake.wrongCount * 20, 60);
        const reviewPenalty = mistake.reviewCount * 10;
        const timeBonus = Math.max(0, 40 - hoursSinceLastWrong);
        
        return Math.max(0, wrongCountBonus + timeBonus - reviewPenalty);
    },
    
    getFormattedDate: () => {
        return new Date().toLocaleDateString('zh-CN');
    },
    
    getAll: () => {
        const storageKey = ProfileManager.getProfileKey('mistake_list');
        return JSON.parse(localStorage.getItem(storageKey) || '[]');
    },
    
    getPriorityMistakes: (limit = 5) => {
        const mistakes = MistakeManager.getAll();
        const now = new Date().getTime();
        
        mistakes.forEach(m => {
            m.priority = MistakeManager.calculatePriority(m);
        });
        
        return mistakes
            .sort((a, b) => b.priority - a.priority)
            .slice(0, limit);
    },
    
    markReviewed: (questionStr) => {
        const storageKey = ProfileManager.getProfileKey('mistake_list');
        let mistakes = JSON.parse(localStorage.getItem(storageKey) || '[]');
        const index = mistakes.findIndex(m => m.question === questionStr);
        
        if (index !== -1) {
            mistakes[index].reviewCount = (mistakes[index].reviewCount || 0) + 1;
            mistakes[index].lastReviewTime = new Date().getTime();
            localStorage.setItem(storageKey, JSON.stringify(mistakes));
        }
    },
    
    remove: (questionStr) => {
        const storageKey = ProfileManager.getProfileKey('mistake_list');
        let mistakes = JSON.parse(localStorage.getItem(storageKey) || '[]');
        mistakes = mistakes.filter(m => m.question !== questionStr);
        localStorage.setItem(storageKey, JSON.stringify(mistakes));
    },
    
    clear: () => {
        const storageKey = ProfileManager.getProfileKey('mistake_list');
        localStorage.removeItem(storageKey);
    },
    
    getStats: () => {
        const mistakes = MistakeManager.getAll();
        const highPriority = mistakes.filter(m => m.wrongCount >= 3).length;
        const mediumPriority = mistakes.filter(m => m.wrongCount === 2).length;
        const lowPriority = mistakes.filter(m => m.wrongCount === 1).length;
        
        return {
            total: mistakes.length,
            highPriority,
            mediumPriority,
            lowPriority
        };
    }
};

window.mathApp = {
    currentUser,
    loadUserData,
    saveUserData,
    addQuestionToHistory,
    MistakeManager,
    ProfileManager,
    calculateAbilityMetrics
};

// PWA更新监听
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('Service Worker 注册成功:', registration.scope);
                
                // 监听service worker更新
                registration.addEventListener('updatefound', () => {
                    const newWorker = registration.installing;
                    if (newWorker) {
                        newWorker.addEventListener('statechange', () => {
                            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                                // 有新版本可用
                                showUpdateNotification();
                            }
                        });
                    }
                });
                
                // 监听controllerchange事件
                navigator.serviceWorker.addEventListener('controllerchange', () => {
                    console.log('Service Worker 控制器已更改');
                });
            })
            .catch(error => {
                console.error('Service Worker 注册失败:', error);
            });
    });
    
    // 监听service worker消息
    navigator.serviceWorker.addEventListener('message', event => {
        if (event.data && event.data.type === 'UPDATE_AVAILABLE') {
            showUpdateNotification();
        }
    });
}

// 显示更新通知
function showUpdateNotification() {
    const updateNotification = document.createElement('div');
    updateNotification.className = 'fixed bottom-4 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-6 py-3 rounded-lg shadow-lg z-50 flex items-center space-x-3';
    updateNotification.innerHTML = `
        <div class="text-xl">🔄</div>
        <div>
            <div class="font-medium">应用已更新</div>
            <div class="text-sm">点击刷新获取最新功能</div>
        </div>
        <button onclick="window.location.reload()" class="bg-white text-blue-600 px-3 py-1 rounded font-medium">刷新</button>
    `;
    
    document.body.appendChild(updateNotification);
    
    // 30秒后自动消失
    setTimeout(() => {
        if (updateNotification.parentNode) {
            updateNotification.style.opacity = '0';
            updateNotification.style.transition = 'opacity 0.5s';
            setTimeout(() => {
                updateNotification.remove();
            }, 500);
        }
    }, 30000);
}

// 计算能力指标
function calculateAbilityMetrics() {
    const profileId = ProfileManager.getCurrentProfileId();
    const history = JSON.parse(localStorage.getItem('questionHistory_' + profileId) || '[]');
    
    const metrics = {
        calculation: { correct: 0, total: 0 },
        logic: { correct: 0, total: 0 },
        geometry: { correct: 0, total: 0 },
        application: { correct: 0, total: 0 },
        numberSense: { correct: 0, total: 0 }
    };
    
    history.forEach(item => {
        const category = getQuestionCategory(item.question, item.type);
        if (metrics[category]) {
            metrics[category].total++;
            if (item.isCorrect) metrics[category].correct++;
        }
    });
    
    return metrics;
}

// 获取题目类别
function getQuestionCategory(question, type) {
    if (type.includes('加法') || type.includes('减法') || type.includes('乘法') || type.includes('除法') || type.includes('混合运算')) {
        return 'calculation';
    } else if (type.includes('方程') || type.includes('比例') || type.includes('百分数')) {
        return 'logic';
    } else if (type.includes('几何') || type.includes('面积') || type.includes('周长')) {
        return 'geometry';
    } else if (type.includes('应用')) {
        return 'application';
    } else {
        return 'numberSense';
    }
}

function showProfileSwitcher() {
    const profiles = ProfileManager.getAllProfiles();
    const currentId = ProfileManager.getCurrentProfileId();
    
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.innerHTML = `
        <div class="bg-white rounded-3xl p-8 max-w-md mx-4 transform scale-0" id="profileModal">
            <div class="text-center mb-6">
                <h3 class="text-2xl font-bold text-gray-800 mb-2">👤 档案管理</h3>
                <p class="text-gray-600">切换或创建学习档案</p>
            </div>
            
            <div class="space-y-3 mb-6 max-h-60 overflow-y-auto">
                ${profiles.map(p => `
                    <div class="flex items-center justify-between p-3 rounded-xl ${p.id === currentId ? 'bg-blue-100 border-2 border-blue-400' : 'bg-gray-50 hover:bg-gray-100'} cursor-pointer transition-all" onclick="switchProfile('${p.id}')">
                        <div class="flex items-center space-x-3">
                            <div class="w-10 h-10 rounded-full bg-gradient-to-r from-blue-400 to-purple-500 flex items-center justify-center text-white font-bold">${p.avatar}</div>
                            <div>
                                <div class="font-medium text-gray-800">${p.name}</div>
                                <div class="text-xs text-gray-500">${p.id === currentId ? '当前档案' : '点击切换'}</div>
                            </div>
                        </div>
                        ${p.id !== 'default' ? `<button onclick="event.stopPropagation(); deleteProfile('${p.id}')" class="text-red-400 hover:text-red-600 text-sm">删除</button>` : ''}
                    </div>
                `).join('')}
            </div>
            
            <div class="border-t border-gray-200 pt-4">
                <div class="flex space-x-2">
                    <input type="text" id="newProfileName" placeholder="输入新档案名称" class="flex-1 border border-gray-300 rounded-xl px-4 py-2 focus:outline-none focus:border-blue-400">
                    <button onclick="createNewProfile()" class="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-xl font-medium hover:from-blue-600 hover:to-purple-700 transition-all">
                        创建
                    </button>
                </div>
            </div>
            
            <div class="text-center mt-6">
                <button onclick="closeProfileModal()" class="text-gray-500 hover:text-gray-700 transition-colors">
                    关闭
                </button>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    anime({
        targets: '#profileModal',
        scale: [0, 1],
        duration: 300,
        easing: 'easeOutBack'
    });
}

// 切换档案
function switchProfile(profileId) {
    ProfileManager.setCurrentProfileId(profileId);
    closeProfileModal();
    // 重新加载数据
    location.reload();
}

// 创建新档案
function createNewProfile() {
    const nameInput = document.getElementById('newProfileName');
    const name = nameInput.value.trim();
    
    if (!name) {
        alert('请输入档案名称');
        return;
    }
    
    const newId = ProfileManager.createProfile(name);
    ProfileManager.setCurrentProfileId(newId);
    closeProfileModal();
    location.reload();
}

// 删除档案
function deleteProfile(profileId) {
    if (profileId === 'default') {
        alert('默认档案不能删除');
        return;
    }
    
    showParentalLock(() => {
        ProfileManager.deleteProfile(profileId);
        closeProfileModal();
        location.reload();
    });
}

// 关闭档案弹窗
function closeProfileModal() {
    const modal = document.querySelector('.fixed.inset-0');
    if (modal) {
        anime({
            targets: '#profileModal',
            scale: [1, 0],
            duration: 200,
            easing: 'easeInBack',
            complete: () => modal.remove()
        });
    }
}

// 家长防护锁 - 数学题验证
function showParentalLock(callback) {
    const a = Math.floor(Math.random() * 10) + 1;
    const b = Math.floor(Math.random() * 10) + 1;
    const answer = a * b;
    
    const modal = document.createElement('div');
    modal.className = 'fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50';
    modal.id = 'parentalLockModal';
    modal.innerHTML = `
        <div class="bg-white rounded-3xl p-8 max-w-md mx-4 transform scale-0" id="parentalLockContent">
            <div class="text-center">
                <div class="text-6xl mb-4">🔒</div>
                <h3 class="text-2xl font-bold text-gray-800 mb-4">家长验证</h3>
                <p class="text-gray-600 mb-6">请回答以下问题以继续操作</p>
                
                <div class="bg-gradient-to-r from-orange-100 to-yellow-100 rounded-2xl p-6 mb-6">
                    <div class="text-4xl font-bold text-gray-800 mb-4">${a} × ${b} = ?</div>
                    <input type="number" 
                           id="parentalAnswer" 
                           class="w-full text-center text-2xl font-bold border-2 border-orange-300 rounded-xl py-3 px-4 focus:outline-none focus:border-orange-500"
                           placeholder="输入答案"
                           inputmode="numeric">
                </div>
                
                <div class="flex space-x-4">
                    <button onclick="closeParentalLock()" class="flex-1 bg-gray-200 text-gray-800 py-3 px-6 rounded-xl font-medium hover:bg-gray-300 transition-colors">
                        取消
                    </button>
                    <button onclick="verifyParentalLock(${answer})" class="flex-1 bg-gradient-to-r from-orange-500 to-red-500 text-white py-3 px-6 rounded-xl font-medium hover:from-orange-600 hover:to-red-600 transition-all">
                        确认
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    anime({
        targets: '#parentalLockContent',
        scale: [0, 1],
        duration: 300,
        easing: 'easeOutBack'
    });
    
    const answerInput = document.getElementById('parentalAnswer');
    answerInput.focus();
    
    answerInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            verifyParentalLock(answer);
        }
    });
    
    window.parentalLockCallback = callback;
}

// 验证家长答案
function verifyParentalLock(correctAnswer) {
    const userAnswer = parseInt(document.getElementById('parentalAnswer').value);
    
    if (userAnswer === correctAnswer) {
        closeParentalLock();
        if (window.parentalLockCallback) {
            window.parentalLockCallback();
            window.parentalLockCallback = null;
        }
    } else {
        alert('答案错误，请重试');
        document.getElementById('parentalAnswer').value = '';
        document.getElementById('parentalAnswer').focus();
    }
}

// 关闭家长防护锁
function closeParentalLock() {
    const modal = document.getElementById('parentalLockModal');
    if (modal) {
        anime({
            targets: '#parentalLockContent',
            scale: [1, 0],
            duration: 200,
            easing: 'easeInBack',
            complete: () => modal.remove()
        });
    }
    window.parentalLockCallback = null;
}