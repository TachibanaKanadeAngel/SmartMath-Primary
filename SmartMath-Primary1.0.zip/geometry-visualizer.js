class GeometryVisualizer {
    constructor(containerId) {
        this.containerId = containerId;
        this.canvas = null;
        this.ctx = null;
        this.width = 300;
        this.height = 200;
        this.init();
    }

    init() {
        const container = document.getElementById(this.containerId);
        if (!container) return;
        
        container.innerHTML = '';
        
        this.canvas = document.createElement('canvas');
        this.canvas.width = this.width;
        this.canvas.height = this.height;
        this.canvas.style.cssText = 'border-radius: 12px; background: #fafafa; margin: 10px auto; display: block;';
        container.appendChild(this.canvas);
        
        this.ctx = this.canvas.getContext('2d');
        this.clear();
    }

    clear() {
        if (this.ctx) {
            this.ctx.fillStyle = '#fafafa';
            this.ctx.fillRect(0, 0, this.width, this.height);
        }
    }

    drawCircle(radius, label = '') {
        this.clear();
        const centerX = this.width / 2;
        const centerY = this.height / 2;
        const r = Math.min(radius * 15, 80);
        
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, r, 0, Math.PI * 2);
        this.ctx.strokeStyle = '#4A90E2';
        this.ctx.lineWidth = 3;
        this.ctx.stroke();
        this.ctx.fillStyle = 'rgba(74, 144, 226, 0.1)';
        this.ctx.fill();
        
        this.ctx.beginPath();
        this.ctx.moveTo(centerX, centerY);
        this.ctx.lineTo(centerX + r, centerY);
        this.ctx.strokeStyle = '#e74c3c';
        this.ctx.lineWidth = 2;
        this.ctx.setLineDash([5, 3]);
        this.ctx.stroke();
        this.ctx.setLineDash([]);
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.fillText(`r = ${radius}`, centerX + r/2 - 15, centerY - 8);
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(label || `圆 (半径: ${radius})`, centerX, this.height - 15);
        
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, 3, 0, Math.PI * 2);
        this.ctx.fillStyle = '#333';
        this.ctx.fill();
    }

    drawRectangle(width, height, label = '') {
        this.clear();
        
        const maxW = 200;
        const maxH = 120;
        const scale = Math.min(maxW / width, maxH / height, 1);
        const w = width * scale;
        const h = height * scale;
        
        const startX = (this.width - w) / 2;
        const startY = (this.height - h) / 2;
        
        this.ctx.fillStyle = 'rgba(46, 204, 113, 0.15)';
        this.ctx.fillRect(startX, startY, w, h);
        
        this.ctx.strokeStyle = '#2ecc71';
        this.ctx.lineWidth = 3;
        this.ctx.strokeRect(startX, startY, w, h);
        
        this.ctx.fillStyle = '#2ecc71';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${width}`, startX + w/2, startY - 5);
        
        this.ctx.save();
        this.ctx.translate(startX - 10, startY + h/2);
        this.ctx.rotate(-Math.PI/2);
        this.ctx.fillText(`${height}`, 0, 0);
        this.ctx.restore();
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.fillText(label || `长方形 (${width} × ${height})`, this.width/2, this.height - 10);
    }

    drawSquare(side, label = '') {
        this.clear();
        
        const maxS = 120;
        const s = Math.min(side * 10, maxS);
        
        const startX = (this.width - s) / 2;
        const startY = (this.height - s) / 2;
        
        this.ctx.fillStyle = 'rgba(155, 89, 182, 0.15)';
        this.ctx.fillRect(startX, startY, s, s);
        
        this.ctx.strokeStyle = '#9b59b6';
        this.ctx.lineWidth = 3;
        this.ctx.strokeRect(startX, startY, s, s);
        
        this.ctx.fillStyle = '#9b59b6';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${side}`, startX + s/2, startY - 5);
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.fillText(label || `正方形 (边长: ${side})`, this.width/2, this.height - 10);
    }

    drawTriangle(base, height, label = '') {
        this.clear();
        
        const maxW = 200;
        const maxH = 130;
        const scale = Math.min(maxW / base, maxH / height, 1);
        const b = base * scale;
        const h = height * scale;
        
        const startX = (this.width - b) / 2;
        const startY = (this.height + h) / 2 - 10;
        
        this.ctx.beginPath();
        this.ctx.moveTo(startX, startY);
        this.ctx.lineTo(startX + b, startY);
        this.ctx.lineTo(startX + b/2, startY - h);
        this.ctx.closePath();
        
        this.ctx.fillStyle = 'rgba(241, 196, 15, 0.2)';
        this.ctx.fill();
        
        this.ctx.strokeStyle = '#f39c12';
        this.ctx.lineWidth = 3;
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.moveTo(startX + b/2, startY - h);
        this.ctx.lineTo(startX + b/2, startY);
        this.ctx.strokeStyle = '#e74c3c';
        this.ctx.lineWidth = 1;
        this.ctx.setLineDash([4, 3]);
        this.ctx.stroke();
        this.ctx.setLineDash([]);
        
        this.ctx.fillStyle = '#f39c12';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`底: ${base}`, startX + b/2, startY + 15);
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.fillText(`高: ${height}`, startX + b/2 + 35, startY - h/2);
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.fillText(label || `三角形`, this.width/2, this.height - 5);
    }

    drawFraction(numerator, denominator) {
        this.clear();
        
        const centerX = this.width / 2;
        const centerY = this.height / 2 - 10;
        const radius = 60;
        
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        this.ctx.strokeStyle = '#3498db';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        
        const angleStep = (Math.PI * 2) / denominator;
        
        for (let i = 0; i < numerator; i++) {
            const startAngle = -Math.PI/2 + i * angleStep;
            const endAngle = startAngle + angleStep;
            
            this.ctx.beginPath();
            this.ctx.moveTo(centerX, centerY);
            this.ctx.arc(centerX, centerY, radius, startAngle, endAngle);
            this.ctx.closePath();
            this.ctx.fillStyle = `hsl(${200 + i * 30}, 70%, 60%)`;
            this.ctx.fill();
            this.ctx.strokeStyle = '#fff';
            this.ctx.lineWidth = 1;
            this.ctx.stroke();
        }
        
        for (let i = 0; i < denominator; i++) {
            const angle = -Math.PI/2 + i * angleStep + angleStep/2;
            this.ctx.beginPath();
            this.ctx.moveTo(centerX, centerY);
            this.ctx.lineTo(centerX + radius * Math.cos(angle), centerY + radius * Math.sin(angle));
            this.ctx.strokeStyle = '#3498db';
            this.ctx.lineWidth = 1;
            this.ctx.stroke();
        }
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 20px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${numerator}/${denominator}`, centerX, this.height - 15);
    }

    drawNumberLine(value, min = 0, max = 10) {
        this.clear();
        
        const padding = 30;
        const lineY = this.height / 2;
        const lineLength = this.width - padding * 2;
        const startX = padding;
        
        this.ctx.beginPath();
        this.ctx.moveTo(startX, lineY);
        this.ctx.lineTo(startX + lineLength, lineY);
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.moveTo(startX + lineLength, lineY);
        this.ctx.lineTo(startX + lineLength - 10, lineY - 5);
        this.ctx.lineTo(startX + lineLength - 10, lineY + 5);
        this.ctx.closePath();
        this.ctx.fillStyle = '#333';
        this.ctx.fill();
        
        const range = max - min;
        const step = lineLength / range;
        
        for (let i = 0; i <= range; i++) {
            const x = startX + i * step;
            
            this.ctx.beginPath();
            this.ctx.moveTo(x, lineY - 8);
            this.ctx.lineTo(x, lineY + 8);
            this.ctx.strokeStyle = '#333';
            this.ctx.lineWidth = 1;
            this.ctx.stroke();
            
            this.ctx.fillStyle = '#333';
            this.ctx.font = '11px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText((min + i).toString(), x, lineY + 22);
        }
        
        const valueX = startX + (value - min) * step;
        
        this.ctx.beginPath();
        this.ctx.arc(valueX, lineY, 8, 0, Math.PI * 2);
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.fill();
        this.ctx.strokeStyle = '#c0392b';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(value.toString(), valueX, lineY - 18);
    }

    drawPercentage(percent) {
        this.clear();
        
        const barWidth = 220;
        const barHeight = 30;
        const startX = (this.width - barWidth) / 2;
        const startY = this.height / 2 - barHeight / 2 - 10;
        
        this.ctx.fillStyle = '#ecf0f1';
        this.ctx.fillRect(startX, startY, barWidth, barHeight);
        
        const filledWidth = (percent / 100) * barWidth;
        
        const gradient = this.ctx.createLinearGradient(startX, startY, startX + filledWidth, startY);
        gradient.addColorStop(0, '#3498db');
        gradient.addColorStop(1, '#2ecc71');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(startX, startY, filledWidth, barHeight);
        
        this.ctx.strokeStyle = '#bdc3c7';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(startX, startY, barWidth, barHeight);
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 24px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${percent}%`, this.width/2, this.height - 20);
        
        for (let i = 1; i < 4; i++) {
            const x = startX + (barWidth / 4) * i;
            this.ctx.beginPath();
            this.ctx.moveTo(x, startY);
            this.ctx.lineTo(x, startY + barHeight);
            this.ctx.strokeStyle = '#bdc3c7';
            this.ctx.lineWidth = 1;
            this.ctx.stroke();
        }
    }

    drawRatio(a, b) {
        this.clear();
        
        const maxVal = Math.max(a, b);
        const scale = 80 / maxVal;
        const barHeight = 25;
        const gap = 40;
        
        const bar1Width = a * scale;
        const bar2Width = b * scale;
        
        const totalWidth = bar1Width + gap + bar2Width;
        const startX = (this.width - totalWidth) / 2;
        const startY = this.height / 2 - barHeight / 2;
        
        this.ctx.fillStyle = '#3498db';
        this.ctx.fillRect(startX, startY, bar1Width, barHeight);
        this.ctx.fillStyle = '#fff';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(a.toString(), startX + bar1Width/2, startY + barHeight/2 + 5);
        
        this.ctx.fillStyle = '#2ecc71';
        this.ctx.fillRect(startX + bar1Width + gap, startY, bar2Width, barHeight);
        this.ctx.fillStyle = '#fff';
        this.ctx.fillText(b.toString(), startX + bar1Width + gap + bar2Width/2, startY + barHeight/2 + 5);
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 18px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${a} : ${b}`, this.width/2, this.height - 15);
        
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(startX, startY, bar1Width, barHeight);
        this.ctx.strokeRect(startX + bar1Width + gap, startY, bar2Width, barHeight);
    }

    drawMultiplication(a, b) {
        this.clear();
        
        const rows = Math.min(a, 10);
        const cols = Math.min(b, 10);
        
        const cellSize = 20;
        const gap = 3;
        const totalWidth = cols * (cellSize + gap) - gap;
        const totalHeight = rows * (cellSize + gap) - gap;
        
        const startX = (this.width - totalWidth) / 2;
        const startY = (this.height - totalHeight) / 2 - 10;
        
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
                const x = startX + j * (cellSize + gap);
                const y = startY + i * (cellSize + gap);
                
                this.ctx.fillStyle = `hsl(${200 + (i + j) * 10}, 70%, 60%)`;
                this.ctx.fillRect(x, y, cellSize, cellSize);
                this.ctx.strokeStyle = '#fff';
                this.ctx.lineWidth = 1;
                this.ctx.strokeRect(x, y, cellSize, cellSize);
            }
        }
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 16px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`${a} × ${b} = ${a * b}`, this.width/2, this.height - 10);
    }

    drawDivision(dividend, divisor) {
        this.clear();
        
        const quotient = Math.floor(dividend / divisor);
        const remainder = dividend % divisor;
        
        const itemsPerRow = Math.min(divisor, 8);
        const cellSize = 18;
        const gap = 2;
        
        const totalItems = Math.min(dividend, 24);
        const rows = Math.ceil(totalItems / itemsPerRow);
        
        const totalWidth = itemsPerRow * (cellSize + gap) - gap;
        const startX = (this.width - totalWidth) / 2;
        const startY = 20;
        
        let count = 0;
        for (let i = 0; i < rows && count < totalItems; i++) {
            for (let j = 0; j < itemsPerRow && count < totalItems; j++) {
                const x = startX + j * (cellSize + gap);
                const y = startY + i * (cellSize + gap);
                
                const groupIndex = Math.floor(count / divisor);
                this.ctx.fillStyle = `hsl(${groupIndex * 60}, 70%, 55%)`;
                this.ctx.beginPath();
                this.ctx.arc(x + cellSize/2, y + cellSize/2, cellSize/2 - 1, 0, Math.PI * 2);
                this.ctx.fill();
                
                count++;
            }
        }
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.textAlign = 'center';
        
        let text = `${dividend} ÷ ${divisor} = ${quotient}`;
        if (remainder > 0) {
            text += ` ... ${remainder}`;
        }
        this.ctx.fillText(text, this.width/2, this.height - 25);
        
        this.ctx.font = '12px Arial';
        this.ctx.fillStyle = '#666';
        this.ctx.fillText(`每组${divisor}个，共${quotient}组`, this.width/2, this.height - 8);
    }

    drawCylinder(radius, height, label = '') {
        this.clear();
        
        const centerX = this.width / 2;
        const centerY = this.height / 2;
        const scale = Math.min(8, 60 / Math.max(radius, height / 2));
        const r = radius * scale;
        const h = height * scale;
        
        const topY = centerY - h / 2;
        const bottomY = centerY + h / 2;
        
        this.ctx.strokeStyle = '#3498db';
        this.ctx.lineWidth = 2;
        
        this.ctx.beginPath();
        this.ctx.ellipse(centerX, topY, r, r * 0.3, 0, 0, Math.PI * 2);
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.moveTo(centerX - r, topY);
        this.ctx.lineTo(centerX - r, bottomY);
        this.ctx.lineTo(centerX + r, bottomY);
        this.ctx.lineTo(centerX + r, topY);
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.ellipse(centerX, bottomY, r, r * 0.3, 0, 0, Math.PI);
        this.ctx.stroke();
        
        this.ctx.fillStyle = 'rgba(52, 152, 219, 0.1)';
        this.ctx.beginPath();
        this.ctx.ellipse(centerX, bottomY, r, r * 0.3, 0, 0, Math.PI);
        this.ctx.lineTo(centerX + r, topY);
        this.ctx.ellipse(centerX, topY, r, r * 0.3, 0, Math.PI, Math.PI * 2);
        this.ctx.lineTo(centerX - r, bottomY);
        this.ctx.closePath();
        this.ctx.fill();
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`r = ${radius}`, centerX + r + 15, centerY);
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.fillText(`h = ${height}`, centerX + r + 15, centerY + h / 4);
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.fillText(label || `圆柱 (半径: ${radius}, 高: ${height})`, centerX, this.height - 10);
    }

    drawCone(radius, height, label = '') {
        this.clear();
        
        const centerX = this.width / 2;
        const centerY = this.height / 2;
        const scale = Math.min(8, 60 / Math.max(radius, height / 2));
        const r = radius * scale;
        const h = height * scale;
        
        const topY = centerY - h / 2;
        const bottomY = centerY + h / 2;
        
        this.ctx.strokeStyle = '#9b59b6';
        this.ctx.lineWidth = 2;
        
        this.ctx.beginPath();
        this.ctx.moveTo(centerX, topY);
        this.ctx.lineTo(centerX - r, bottomY);
        this.ctx.lineTo(centerX + r, bottomY);
        this.ctx.closePath();
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.ellipse(centerX, bottomY, r, r * 0.3, 0, 0, Math.PI);
        this.ctx.stroke();
        
        this.ctx.fillStyle = 'rgba(155, 89, 182, 0.1)';
        this.ctx.beginPath();
        this.ctx.moveTo(centerX, topY);
        this.ctx.lineTo(centerX - r, bottomY);
        this.ctx.ellipse(centerX, bottomY, r, r * 0.3, 0, 0, Math.PI);
        this.ctx.lineTo(centerX + r, bottomY);
        this.ctx.closePath();
        this.ctx.fill();
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`r = ${radius}`, centerX + r + 15, centerY);
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.fillText(`h = ${height}`, centerX + r + 15, centerY + h / 4);
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.fillText(label || `圆锥 (半径: ${radius}, 高: ${height})`, centerX, this.height - 10);
    }

    drawBarChart(data, label = '') {
        this.clear();
        
        const padding = 30;
        const chartWidth = this.width - padding * 2;
        const chartHeight = this.height - padding * 2 - 20;
        const barWidth = (chartWidth / data.length) - 5;
        const maxScore = 100;
        
        const startX = padding;
        const startY = this.height - padding - 20;
        
        this.ctx.strokeStyle = '#ddd';
        this.ctx.lineWidth = 1;
        
        for (let i = 0; i <= 5; i++) {
            const y = startY - (chartHeight / 5) * i;
            this.ctx.beginPath();
            this.ctx.moveTo(padding, y);
            this.ctx.lineTo(this.width - padding, y);
            this.ctx.stroke();
            
            this.ctx.fillStyle = '#666';
            this.ctx.font = '10px Arial';
            this.ctx.textAlign = 'right';
            this.ctx.fillText((i * 20).toString(), padding - 5, y + 3);
        }
        
        const colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#e67e22', '#34495e', '#16a085', '#c0392b'];
        
        data.forEach((score, index) => {
            const x = startX + index * (barWidth + 5);
            const barHeight = (score / maxScore) * chartHeight;
            const y = startY - barHeight;
            
            this.ctx.fillStyle = colors[index % colors.length];
            this.ctx.fillRect(x, y, barWidth, barHeight);
            
            this.ctx.strokeStyle = '#fff';
            this.ctx.lineWidth = 1;
            this.ctx.strokeRect(x, y, barWidth, barHeight);
            
            this.ctx.fillStyle = '#333';
            this.ctx.font = '9px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(score.toString(), x + barWidth / 2, y - 5);
        });
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(label || '成绩统计', this.width / 2, this.height - 5);
    }

    drawFunctionGraph(type, params = {}) {
        this.clear();
        
        const centerX = this.width / 2;
        const centerY = this.height / 2;
        const scale = 20;
        
        this.ctx.strokeStyle = '#ddd';
        this.ctx.lineWidth = 1;
        
        this.ctx.beginPath();
        this.ctx.moveTo(0, centerY);
        this.ctx.lineTo(this.width, centerY);
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.moveTo(centerX, 0);
        this.ctx.lineTo(centerX, this.height);
        this.ctx.stroke();
        
        for (let i = -5; i <= 5; i++) {
            if (i !== 0) {
                this.ctx.beginPath();
                this.ctx.moveTo(centerX + i * scale, centerY - 3);
                this.ctx.lineTo(centerX + i * scale, centerY + 3);
                this.ctx.stroke();
                
                this.ctx.beginPath();
                this.ctx.moveTo(centerX - 3, centerY - i * scale);
                this.ctx.lineTo(centerX + 3, centerY - i * scale);
                this.ctx.stroke();
            }
        }
        
        this.ctx.beginPath();
        this.ctx.strokeStyle = '#e74c3c';
        this.ctx.lineWidth = 2;
        
        let firstPoint = true;
        
        for (let px = 0; px < this.width; px++) {
            const x = (px - centerX) / scale;
            let y;
            
            switch (type) {
                case 'linear':
                    const k = params.k || 1;
                    const b = params.b || 0;
                    y = k * x + b;
                    break;
                case 'quadratic':
                    const a = params.a || 1;
                    y = a * x * x;
                    break;
                case 'inverse':
                    if (Math.abs(x) < 0.1) continue;
                    y = 1 / x;
                    break;
                default:
                    y = x;
            }
            
            const py = centerY - y * scale;
            
            if (py > 0 && py < this.height) {
                if (firstPoint) {
                    this.ctx.moveTo(px, py);
                    firstPoint = false;
                } else {
                    this.ctx.lineTo(px, py);
                }
            } else {
                firstPoint = true;
            }
        }
        
        this.ctx.stroke();
        
        this.ctx.fillStyle = '#333';
        this.ctx.font = 'bold 12px Arial';
        this.ctx.textAlign = 'center';
        
        let label = '';
        switch (type) {
            case 'linear':
                label = `y = ${params.k || 1}x + ${params.b || 0}`;
                break;
            case 'quadratic':
                label = `y = x²`;
                break;
            case 'inverse':
                label = `y = 1/x`;
                break;
        }
        this.ctx.fillText(label, centerX, this.height - 5);
    }

    drawInteractiveFunction(k = 1) {
        this.clear();
        
        const centerX = this.width / 2;
        const centerY = this.height / 2;
        const scale = 20;
        
        this.ctx.strokeStyle = '#ddd';
        this.ctx.lineWidth = 1;
        
        this.ctx.beginPath();
        this.ctx.moveTo(0, centerY);
        this.ctx.lineTo(this.width, centerY);
        this.ctx.stroke();
        
        this.ctx.beginPath();
        this.ctx.moveTo(centerX, 0);
        this.ctx.lineTo(centerX, this.height);
        this.ctx.stroke();
        
        for (let i = -5; i <= 5; i++) {
            if (i !== 0) {
                this.ctx.beginPath();
                this.ctx.moveTo(centerX + i * scale, centerY - 3);
                this.ctx.lineTo(centerX + i * scale, centerY + 3);
                this.ctx.stroke();
                
                this.ctx.beginPath();
                this.ctx.moveTo(centerX - 3, centerY - i * scale);
                this.ctx.lineTo(centerX + 3, centerY - i * scale);
                this.ctx.stroke();
            }
        }
        
        this.ctx.beginPath();
        this.ctx.strokeStyle = '#e74c3c';
        this.ctx.lineWidth = 3;
        
        let firstPoint = true;
        
        for (let px = 0; px < this.width; px++) {
            const x = (px - centerX) / scale;
            const y = k * x;
            const py = centerY - y * scale;
            
            if (py > 0 && py < this.height) {
                if (firstPoint) {
                    this.ctx.moveTo(px, py);
                    firstPoint = false;
                } else {
                    this.ctx.lineTo(px, py);
                }
            } else {
                firstPoint = true;
            }
        }
        
        this.ctx.stroke();
        
        this.ctx.fillStyle = '#e74c3c';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(`y = ${k}x`, centerX, this.height - 5);
        
        this.ctx.fillStyle = '#666';
        this.ctx.font = '11px Arial';
        this.ctx.fillText(`比例系数 k = ${k}`, centerX, this.height - 20);
    }

    visualize(question, questionType) {
        this.init();
        
        const type = questionType || '';
        
        // 几何题目检测 - 5-6年级
        if (type.includes('圆') && (type.includes('面积') || type.includes('周长'))) {
            const match = question.match(/半径(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            if (match) {
                const radius = parseFloat(match[1]);
                this.drawCircle(radius, type.includes('面积') ? '圆面积' : '圆周长');
            }
            return;
        }
        
        if (type.includes('长方形') && (type.includes('面积') || type.includes('周长'))) {
            const match = question.match(/长(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)\s*[，,]?\s*宽(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            if (match) {
                const width = parseFloat(match[1]);
                const height = parseFloat(match[2]);
                this.drawRectangle(width, height, type.includes('面积') ? '长方形面积' : '长方形周长');
            }
            return;
        }
        
        if (type.includes('正方形') && (type.includes('面积') || type.includes('周长'))) {
            const match = question.match(/边长(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            if (match) {
                const side = parseFloat(match[1]);
                this.drawSquare(side, type.includes('面积') ? '正方形面积' : '正方形周长');
            }
            return;
        }
        
        if (type.includes('三角形') && (type.includes('面积') || type.includes('周长'))) {
            const match = question.match(/底(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)\s*[，,]?\s*高(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            if (match) {
                const base = parseFloat(match[1]);
                const height = parseFloat(match[2]);
                this.drawTriangle(base, height, type.includes('面积') ? '三角形面积' : '三角形周长');
            }
            return;
        }
        
        if (type.includes('百分数')) {
            const match = question.match(/(\d+(?:\.\d+)?)\s*的\s*(\d+(?:\.\d+)?)%/);
            if (match) {
                this.drawPercentage(parseFloat(match[2]));
            }
            return;
        }
        
        if (type.includes('比例')) {
            const match = question.match(/(\d+):(\d+)/);
            if (match) {
                this.drawRatio(parseInt(match[1]), parseInt(match[2]));
            }
            return;
        }
        
        if (type.includes('分数')) {
            const match = question.match(/(\d+)\/(\d+)/);
            if (match) {
                this.drawFraction(parseInt(match[1]), parseInt(match[2]));
            }
            return;
        }
        
        if (type.includes('乘法')) {
            const match = question.match(/(\d+)\s*×\s*(\d+)/);
            if (match) {
                const a = parseInt(match[1]);
                const b = parseInt(match[2]);
                if (a <= 10 && b <= 10) {
                    this.drawMultiplication(a, b);
                }
            }
            return;
        }
        
        if (type.includes('除法')) {
            const match = question.match(/(\d+)\s*÷\s*(\d+)/);
            if (match) {
                this.drawDivision(parseInt(match[1]), parseInt(match[2]));
            }
            return;
        }
        
        if (type.includes('小数')) {
            const match = question.match(/(\d+\.?\d*)/);
            if (match) {
                const value = parseFloat(match[1]);
                if (value >= 0 && value <= 10) {
                    this.drawNumberLine(value, 0, 10);
                }
            }
            return;
        }
        
        if (type.includes('函数') || type.includes('正比例')) {
            if (question.kValue !== undefined) {
                this.drawInteractiveFunction(question.kValue);
            } else {
                const match = question.match(/比例系数\s*k\s*=\s*(\d+)/);
                const k = match ? parseInt(match[1]) : 1;
                this.drawInteractiveFunction(k);
            }
            return;
        }
        
        if (type.includes('圆柱')) {
            const radiusMatch = question.match(/半径(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            const heightMatch = question.match(/高(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            if (radiusMatch && heightMatch) {
                const radius = parseFloat(radiusMatch[1]);
                const height = parseFloat(heightMatch[1]);
                this.drawCylinder(radius, height, type.includes('体积') ? '圆柱体积' : '圆柱');
            }
            return;
        }
        
        if (type.includes('圆锥')) {
            const radiusMatch = question.match(/半径(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            const heightMatch = question.match(/高(?:为)?\s*[:：]?\s*(\d+(?:\.\d+)?)/);
            if (radiusMatch && heightMatch) {
                const radius = parseFloat(radiusMatch[1]);
                const height = parseFloat(heightMatch[1]);
                this.drawCone(radius, height, type.includes('体积') ? '圆锥体积' : '圆锥');
            }
            return;
        }
        
        if (type.includes('统计')) {
            const match = question.match(/(\d+)[、\d]+/);
            if (match) {
                const scores = question.match(/\d+/g).map(Number);
                this.drawBarChart(scores, '成绩统计');
            }
            return;
        }
    }
}

window.GeometryVisualizer = GeometryVisualizer;
