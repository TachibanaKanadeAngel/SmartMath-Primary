// 测试修复后的函数
console.log("=== 测试修复后的函数 ===");

// 测试三年级乘法
try {
    console.log("\n1. 测试三年级乘法:");
    const grade3Multiplication = MathGenerator.generateGrade3ByType('multiplication');
    console.log("题目:", grade3Multiplication.question);
    console.log("答案:", grade3Multiplication.answer);
    console.log("类型:", grade3Multiplication.type);
    console.log("答案类型:", typeof grade3Multiplication.answer);
    console.log("是否包含乘法符号:", grade3Multiplication.question.includes('×'));
} catch (error) {
    console.error("三年级乘法测试失败:", error);
}

// 测试五年级小数
try {
    console.log("\n2. 测试五年级小数:");
    const grade5Decimal = MathGenerator.generateGrade5ByType('decimal');
    console.log("题目:", grade5Decimal.question);
    console.log("答案:", grade5Decimal.answer);
    console.log("类型:", grade5Decimal.type);
    console.log("答案类型:", typeof grade5Decimal.answer);
    console.log("是否是数字:", typeof grade5Decimal.answer === 'number');
} catch (error) {
    console.error("五年级小数测试失败:", error);
}

// 测试默认行为
try {
    console.log("\n3. 测试默认行为:");
    const grade3Default = MathGenerator.generateGrade3ByType('other');
    console.log("三年级默认题目:", grade3Default.question);
    
    const grade5Default = MathGenerator.generateGrade5ByType('other');
    console.log("五年级默认题目:", grade5Default.question);
} catch (error) {
    console.error("默认行为测试失败:", error);
}

console.log("\n=== 测试完成 ===");
