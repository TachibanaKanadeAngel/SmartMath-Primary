// 修复题目中缺少等号的问题
// 使用方法：读取文件，替换特定行，写回文件

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, 'math-generator.js');

// 读取文件
let content = fs.readFileSync(filePath, 'utf-8');

// 需要修复的位置和替换内容
const fixes = [
    {
        search: 'question: `已知长方形的长为 ${rectW}，宽为 ${rectH}，求面积 S =`,',
        replace: 'question: `已知长方形的长为 ${rectW}，宽为 ${rectH}，求面积 S =`,'
    },
    {
        search: 'question: `已知长方形的长为 ${rectW}，宽为 ${rectH}，求周长 C =`,',
        replace: 'question: `已知长方形的长为 ${rectW}，宽为 ${rectH}，求周长 C =`,'
    },
    {
        search: 'question: `已知正方形的边长为 ${squareSide}，求面积 S =`,',
        replace: 'question: `已知正方形的边长为 ${squareSide}，求面积 S =`,'
    },
    {
        search: 'question: `已知正方形的边长为 ${squareSide}，求周长 C =`,',
        replace: 'question: `已知正方形的边长为 ${squareSide}，求周长 C =`,'
    },
    {
        search: 'question: `已知三角形的底为 ${triBase}，高为 ${triHeight}，求面积 S =`,',
        replace: 'question: `已知三角形的底为 ${triBase}，高为 ${triHeight}，求面积 S =`,'
    },
    {
        search: 'question: `已知正方形的边长为 ${squareSide6}，求周长 C =`,',
        replace: 'question: `已知正方形的边长为 ${squareSide6}，求周长 C =`,'
    },
    {
        search: 'question: `已知正方形的边长为 ${squareSide6}，求面积 S =`,',
        replace: 'question: `已知正方形的边长为 ${squareSide6}，求面积 S =`,'
    }
];

// 应用修复
let modified = false;
fixes.forEach(fix => {
    if (content.includes(fix.search)) {
        content = content.replace(fix.search, fix.replace);
        modified = true;
        console.log(`已修复: ${fix.search.substring(0, 50)}...`);
    }
});

if (modified) {
    // 写回文件
    fs.writeFileSync(filePath, content, 'utf-8');
    console.log('✅ 所有修复已应用！');
} else {
    console.log('⚠️ 未找到需要修复的内容，可能已经修复过了。');
}
