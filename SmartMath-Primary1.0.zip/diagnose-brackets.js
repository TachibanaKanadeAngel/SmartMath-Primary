// 大括号诊断脚本
const fs = require('fs');

const filePath = 'e:\\练习小程序\\OKComputer_小学数学练习小程序\\math-generator.js';
const content = fs.readFileSync(filePath, 'utf-8');

let leftBraces = 0;
let rightBraces = 0;
let stack = [];
const lines = content.split('\n');

console.log('开始诊断大括号...\n');

for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lineNum = i + 1;
    
    for (let j = 0; j < line.length; j++) {
        const char = line[j];
        
        if (char === '{') {
            leftBraces++;
            stack.push({ line: lineNum, char: '{', pos: j });
        } else if (char === '}') {
            rightBraces++;
            if (stack.length > 0) {
                stack.pop();
            } else {
                console.log(`❌ 第 ${lineNum} 行第 ${j + 1} 列：多余的右大括号 }`);
            }
        }
    }
}

console.log(`\n统计结果：`);
console.log(`左大括号 { 数量: ${leftBraces}`);
console.log(`右大括号 } 数量: ${rightBraces}`);
console.log(`缺失的右大括号数量: ${leftBraces - rightBraces}`);

if (stack.length > 0) {
    console.log(`\n未闭合的左大括号位置（最近的几个）：`);
    stack.slice(-10).forEach((item, index) => {
        console.log(`  ${index + 1}. 第 ${item.line} 行第 ${item.pos + 1} 列`);
    });
}

console.log('\n诊断完成！');
