const fs = require('fs');
const path = require('path');

function analyzeBrackets(filePath) {
    const content = fs.readFileSync(filePath, 'utf8');
    let stack = [];
    let errors = [];
    
    // 记录所有括号位置
    for (let i = 0; i < content.length; i++) {
        if (content[i] === '{') {
            stack.push({ char: '{', pos: i, line: content.substring(0, i).split('\n').length });
        } else if (content[i] === '}') {
            if (stack.length === 0) {
                errors.push(`多余右括号 at line ${content.substring(0, i).split('\n').length}`);
            } else {
                stack.pop();
            }
        }
    }
    
    // 报告未闭合的左括号
    stack.forEach(unmatched => {
        errors.push(`未闭合左括号 at line ${unmatched.line}`);
    });
    
    console.log(`文件: ${path.basename(filePath)}`);
    console.log(`左括号: ${content.match(/{/g)?.length || 0}`);
    console.log(`右括号: ${content.match(/}/g)?.length || 0}`);
    console.log(`错误: ${errors.length > 0 ? errors.join('\n  ') : '无'}`);
    
    return errors.length === 0;
}

// 自动扫描项目中的所有JS文件
const jsFiles = ['math-generator.js', 'main.js'];
jsFiles.forEach(file => analyzeBrackets(file));